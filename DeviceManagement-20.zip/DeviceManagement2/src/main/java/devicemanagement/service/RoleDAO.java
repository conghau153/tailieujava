package devicemanagement.service;

import devicemanagement.model.Role;

import java.util.List;

public interface RoleDAO {
    List<Role> getRoleUser(String userId);

}
