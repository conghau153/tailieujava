package devicemanagement.custom;


import devicemanagement.model.Role;
import devicemanagement.service.UserDAO;
import devicemanagement.service.UserDAOImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import devicemanagement.model.User;
import devicemanagement.service.RoleDAO;


import java.util.ArrayList;
import java.util.List;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserDAOImpl userDAO;

    @Autowired
    RoleDAO roleDAO;

    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        User user = userDAO.getUser(username) ;

        if(user==null){
            System.out.println("UserDevice not found");
            throw new UsernameNotFoundException("Username not found");
        }

        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                true, true, true, true,
                getGrantedAuthorities(user));
    }


    private List<GrantedAuthority> getGrantedAuthorities(User user){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        List<Role> listRoleUser = roleDAO.getRoleUser(user.getId());
        for (Role role : listRoleUser){
            authorities.add(new SimpleGrantedAuthority(role.getRole()));
        }

        return authorities;
    }
}
