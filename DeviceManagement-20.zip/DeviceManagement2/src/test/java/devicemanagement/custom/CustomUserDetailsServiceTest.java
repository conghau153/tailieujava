package devicemanagement.custom;

import devicemanagement.model.User;
import devicemanagement.service.UserDAOImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CustomUserDetailsServiceTest {

    @Mock
    UserDAOImpl userDAOIml;

    User user = new User();

    @Before
    public void init(){
        user.setId("152adgf5263d23");
        user.setUsername("admin");
        user.setPassword("admin");
    }

    @Test
    public void loadUserByUsername() {
        when(userDAOIml.getUser("admin")).thenReturn(user);

        User userQuery = userDAOIml.getUser("admin") ;


        assertEquals(user.getId(),userQuery.getId());
        assertEquals(user.getUsername(),userQuery.getUsername());
        assertEquals(user.getPassword(),userQuery.getPassword());
    }
}