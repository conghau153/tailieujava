package devicemanagement.controller;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import sun.misc.BASE64Encoder;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(MockitoJUnitRunner.class)
public class TestDeviceController {

    private MockMvc mockMvc;

    @InjectMocks
    private DeviceController deviceController;

    JSONArray jsonArray= new JSONArray();
    JSONObject json1= new JSONObject();
    JSONObject json2= new JSONObject();

    @Before
    public void init() throws JSONException {
        MockitoAnnotations.initMocks(this);

        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/views/jsp");
        viewResolver.setSuffix(".jsp");

        mockMvc = MockMvcBuilders.standaloneSetup(new DeviceController())
                .setViewResolvers(viewResolver)
                .build();

        json1.put("id","14253122efs411");
        json1.put("name","BGD-2");
        json1.put("address","10.2.3.56");
        json1.put("macAddress","3e:f7:o9:6j:h9:0e");
        json1.put("status","warning");
        json1.put("type","0S6865-U28X");
        json1.put("version","8.5.2.1");

        json2.put("id","14253122efs415");
        json2.put("name","BAD-1");
        json2.put("address","10.2.1.65");
        json2.put("macAddress","3e:f7:f5:a1:p3:n7");
        json2.put("status","up");
        json2.put("type","0S68650");
        json2.put("version","8.6.2.3");
    }

    @Test
    public void TestLogin(){
        assertEquals("login", deviceController.login());
    }

    @Test
    public void TestAccessDenied(){
        assertEquals("Access_Denied",deviceController.accesssDenied());
    }
    @Test
    public void TestLogout() throws Exception {
        mockMvc.perform(get("redirect:/login?logout"))
                .andExpect(status().isOk());
    }

    @Test
    public void TestGetAllDevicesClient(){
        String uRI= "127.0.0.1:8080";
        String username="admin";
        String password="admin";
        String authString = username + ":" + password;
        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());


        Client client = mock( Client.class );
        WebResource webResource = mock( WebResource.class );
        WebResource.Builder builder = mock( WebResource.Builder.class );
        ClientResponse clientResponse = mock( ClientResponse.class );

        when(client.resource(anyString())).thenReturn( webResource );
        when(webResource.accept(anyString())).thenReturn(builder);
        when(builder.header("Authorization", "Basic " + authStringEnc)).thenReturn(builder);
        when(builder.get( ClientResponse.class ) ).thenReturn( clientResponse );

        when(clientResponse.getStatus()).thenReturn(200);
        when(clientResponse.getEntity(JSONArray.class )).thenReturn(jsonArray);

        webResource = client.resource(uRI+ "/api/devices");
        //send a GET with contentType and Basic Authentication
        ClientResponse response = webResource.accept("application/json;charset=UTF-8")
                .header("Authorization", "Basic " + authStringEnc)
                .get(ClientResponse.class);

        assertEquals(200,response.getStatus());
        assertEquals(jsonArray, response.getEntity(JSONArray.class));
    }

    @Test
    public void TestClientGetDeviceById(){
        String uRI= "127.0.0.1:8080";
        String username="admin";
        String password="admin";
        String authString = username + ":" + password;
        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());


        Client client = mock( Client.class );
        WebResource webResource = mock( WebResource.class );
        WebResource.Builder builder = mock( WebResource.Builder.class );
        ClientResponse clientResponse = mock( ClientResponse.class );

        when( builder.get( ClientResponse.class ) ).thenReturn( clientResponse );

        when( webResource.accept( anyString() ) ).thenReturn( builder );
        when( builder.header("Authorization", "Basic " + authStringEnc)).thenReturn(builder);
        when( client.resource( anyString() ) ).thenReturn( webResource );
        when(clientResponse.getStatus()).thenReturn(200);
        when( clientResponse.getEntity( JSONObject.class ) ).thenReturn(json2);

        webResource = client.resource(uRI+ "/api/devices/14253122efs415");
        //send a GET with contentType and Basic Authentication
        ClientResponse response = webResource.accept("application/json;charset=UTF-8")
                .header("Authorization", "Basic " + authStringEnc)
                .get(ClientResponse.class);

        assertEquals(200,response.getStatus());
        assertEquals(json2, response.getEntity(JSONObject.class));
    }


}
