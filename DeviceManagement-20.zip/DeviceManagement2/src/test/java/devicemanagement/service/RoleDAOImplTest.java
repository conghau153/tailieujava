package devicemanagement.service;

import devicemanagement.model.Role;
import devicemanagement.model.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Arrays;
import java.util.List;

import static devicemanagement.service.RoleDAOImpl.CollectionRoleUser;
import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class RoleDAOImplTest {
    @Mock
    MongoTemplate mongoTemplate;

    Role role = new Role();

    @Before
    public void init(){
        role.setId("12452@dfe1as212");
        role.setRole("ROLE_ADMIN");
        role.setUserId("45652fsjd125123");
    }

    @Test
    public void getRoleUser() {
        List<Role> roles = Arrays.asList(new Role[]{role});
        when(mongoTemplate.find(Query.query(Criteria.where("userId").is(role.getUserId())),
                Role.class,CollectionRoleUser)).thenReturn(roles);

        List<Role> listRole= mongoTemplate.find(Query.query(Criteria.where("userId").is("45652fsjd125123")),
                Role.class,"role");

        Role role1= listRole.get(0);
        assertEquals(1,listRole.size() );
        assertEquals(role.getId(),role1.getId());
        assertEquals(role.getRole(),role1.getRole());
        assertEquals(role.getUserId(),role1.getUserId());
    }
}