package devicemanagement.service;

import devicemanagement.model.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class UserDAOImplTest {

    @Mock
    MongoTemplate mongoTemplate;

    @Mock
    UserDAO userDAO;

    User user = new User();

    @Before
    public void init(){
        user.setId("1254sjsv112d15");
        user.setUsername("admin");
        user.setPassword("admin");
    }

    @Test
    public void getUser() {
        when(mongoTemplate.findOne(Query.query(Criteria.where("username").is("admin")),
                User.class,"user")).thenReturn(user);
        User user1= mongoTemplate.findOne(Query.query(Criteria.where("username").is("admin")),
                User.class,"user");
        assertEquals(user.getId(),user1.getId());
        assertEquals(user.getUsername(),user1.getUsername());
        assertEquals(user.getPassword(),user1.getPassword());

    }

}