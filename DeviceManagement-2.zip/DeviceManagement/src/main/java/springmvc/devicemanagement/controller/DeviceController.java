package springmvc.devicemanagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;
import springmvc.devicemanagement.service.DeviceDAO;

import java.util.List;


@Controller
public class DeviceController {
    @Autowired
    private DeviceDAO deviceDao;

    String error="";

    @RequestMapping("/listDevice")
    public ModelAndView listDevice(){
        //write the code to get all device from DAO
        List<ViewDevice> listViewDevice=deviceDao.getListDevice();

        return new ModelAndView("listDevice","list",listViewDevice);
    }

    @RequestMapping("/formDevice")
    public ModelAndView showFormDevice(){
        //command is a reserved request attribute name, now use <form> tag to show object data
        ModelAndView model = new ModelAndView("formDevice");
        model.addObject("command",new ViewDevice());

        //set a message error in form device
        model.addObject("msg",error);
        if (!"".equals(error)) error="";

        return model;
        //return new ModelAndView("deviceform","command",new Device());
    }

    @RequestMapping(value="/save",method = RequestMethod.POST)
    public ModelAndView saveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){
        //check MAC Address in mongoDB
        ViewDevice devi= deviceDao.getDeviceByMacAddress(viewDevice.getMacAddress());

        //check form add new device
        Boolean check = "".equals(viewDevice.getAddress())
                || "".equals(viewDevice.getMacAddress())
                || "".equals(viewDevice.getName())
                || "".equals(viewDevice.getType())
                || "".equals(viewDevice.getVersion())
                || (viewDevice.getName().length()>128)
                || (viewDevice.getType().length()>64)
                || (viewDevice.getVersion().length()>64);


        if (devi!=null || check ){
            error= "Can not add new device ";
            //return new ModelAndView("redirect:/deviceform");
            return showFormDevice();
        }else{
            deviceDao.addDevice(viewDevice);
            return new ModelAndView("redirect:/listDevice");//will redirect to listDevice request mapping
        }

    }


    @RequestMapping(value="/editDevice/{id}")
    public ModelAndView editDevice(@PathVariable String id){
        //get a device by id


        Device device=deviceDao.getDeviceById(id);
        ViewDevice viewDevice;
        if (device!=null){
            viewDevice = new ViewDevice(device);
        }else{
            viewDevice = new ViewDevice();
        }

        //return device to editFormDevice
        return new ModelAndView("editFormDevice","command",viewDevice);
    }



    @RequestMapping(value="/editSave",method = RequestMethod.POST)
    public ModelAndView editSaveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){

        if (viewDevice!= null){
            deviceDao.updateDevice(viewDevice);
        }

        return new ModelAndView("redirect:/listDevice");
    }


    @RequestMapping(value="/deleteDevice/{id}",method = RequestMethod.GET)
    public ModelAndView deleteDevice(@PathVariable("id") String id){


        if (id!=null ){
            ViewDevice viewDevice= new ViewDevice();
            viewDevice.setId(id);
            deviceDao.deleteDevice(viewDevice);
        }

        return new ModelAndView("redirect:/listDevice");
    }




}