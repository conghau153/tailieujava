package springmvc.devicemanagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;
import springmvc.devicemanagement.service.DeviceDAO;

import java.security.Principal;
import java.util.Collection;
import java.util.List;


@Controller
public class DeviceController {
    @Autowired
    private DeviceDAO deviceDao;


    String error="";

    @RequestMapping(value = "/403", method = RequestMethod.GET)
    public ModelAndView accesssDenied(Principal user) {

        ModelAndView model = new ModelAndView();

        if (user != null) {
            model.addObject("msg", "Hi " + user.getName()
                    + ", you do not have permission to access this page!");
        } else {
            model.addObject("msg",
                    "You do not have permission to access this page!");
        }

        model.setViewName("403");
        return model;
    }

    @PreAuthorize("hasAnyRole('ROLE_MEMBER','ROLE_ADMIN')")
    @RequestMapping("/listDevice")
    public ModelAndView listDevice(Principal user){
        /*
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println(user.getName());
        System.out.println(((UserDetails)principal).getAuthorities().toString());*/

        ModelAndView model = null;
        //write the code to get all device from DAO
        List<ViewDevice> listViewDevice=deviceDao.getListDevice();

        model = new ModelAndView("listDevice");
        model.addObject("list",listViewDevice);
        model.addObject("user","user: "+user.getName());

        return model;
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/formDevice", method = RequestMethod.GET)
    public ModelAndView showFormDevice(Principal user){
        ModelAndView model;

        //command is a reserved request attribute name, now use <form> tag to show object data
        model = new ModelAndView("formDevice");
        model.addObject("command",new ViewDevice());
        model.addObject("user","user: "+user.getName());
        //set a message error in form device
        model.addObject("msg",error);
        if (!"".equals(error)) error="";
        return model;
        //return new ModelAndView("deviceform","command",new Device());
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/save",method = RequestMethod.POST)
    public ModelAndView saveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){

            //check MAC Address in mongoDB
            ViewDevice devi= deviceDao.getDeviceByMacAddress(viewDevice.getMacAddress());

            //check form add new device
            Boolean check = "".equals(viewDevice.getAddress())
                    || "".equals(viewDevice.getMacAddress())
                    || "".equals(viewDevice.getName())
                    || "".equals(viewDevice.getType())
                    || "".equals(viewDevice.getVersion())
                    || (viewDevice.getName().length()>128)
                    || (viewDevice.getType().length()>64)
                    || (viewDevice.getVersion().length()>64);

            if (devi!=null || check ){
                error= "Can not add new device ";
                //return new ModelAndView("redirect:/deviceform");
                //System.out.println(user.getName());
                //return showFormDevice(user);
                return new ModelAndView("redirect:/formDevice");
            }else{
                deviceDao.addDevice(viewDevice);
                return new ModelAndView("redirect:/listDevice");//will redirect to listDevice request mapping
            }
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/editDevice/{id}",method = RequestMethod.GET)
    public ModelAndView editDevice(@PathVariable String id){
            //get a device by id
            Device device=deviceDao.getDeviceById(id);
            ViewDevice viewDevice;
            if (device!=null){
                viewDevice = new ViewDevice(device);
            }else{
                viewDevice = new ViewDevice();
            }

            //return device to editFormDevice
            return new ModelAndView("editFormDevice","command",viewDevice);

    }


    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/editSave",method = RequestMethod.POST)
    public ModelAndView editSaveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){
            if (viewDevice!= null){
                deviceDao.updateDevice(viewDevice);
            }
            return new ModelAndView("redirect:/listDevice");
    }


    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/deleteDevice/{id}")
    public ModelAndView deleteDevice(@PathVariable("id") String id){
            if (id!=null ){
                ViewDevice viewDevice= new ViewDevice();
                viewDevice.setId(id);
                deviceDao.deleteDevice(viewDevice);
            }
            return new ModelAndView("redirect:/listDevice");
    }


}