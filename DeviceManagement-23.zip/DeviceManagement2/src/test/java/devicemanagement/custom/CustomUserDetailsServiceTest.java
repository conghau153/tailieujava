package devicemanagement.custom;

import devicemanagement.model.Role;
import devicemanagement.model.User;
import devicemanagement.service.RoleDAO;
import devicemanagement.service.UserDAO;
import devicemanagement.service.UserDAOImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CustomUserDetailsServiceTest {

    @Mock
    UserDAO userDAO;
    @Mock
    RoleDAO roleDAO;

    @InjectMocks
    CustomUserDetailsService customUserDetailsService;

    User user = new User();
    Role role= new Role();

    @Before
    public void init(){
        user.setId("152a3gf5263d23");
        user.setUsername("admin");
        user.setPassword("admin");

        role.setId("124s6d1f4d23");
        role.setUserId("152a3gf5263d23");
        role.setRole("ROLE_ADMIN");
    }

    @Test
    public void loadUserByUsernameTest() {
        List<Role> listRole= new ArrayList<Role>(Arrays.asList(new Role[]{role}));

        when(userDAO.getUser("admin")).thenReturn(user);
        when(userDAO.getUser("abc")).thenReturn(null);
        when(roleDAO.getRoleUser("152a3gf5263d23")).thenReturn(listRole);


        customUserDetailsService.loadUserByUsername("admin");
        verify(userDAO,times(1)).getUser("admin");
        customUserDetailsService.loadUserByUsername("abc");
        verify(userDAO,times(1)).getUser("abc");
    }

}