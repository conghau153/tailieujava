package devicemanagement.schedule;

import devicemanagement.model.DeviceEvent;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.MINUTES;

public class ScheduleExecutor {
    @Autowired
    DeviceDAO deviceDAO;

    DeviceEvent deviceEvent=new DeviceEvent();

    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1);

    final Runnable beeper = new Runnable() {
        public void run() {
                deviceEvent.setMacAddress(deviceDAO.getMacAddress());
                deviceEvent.setStatus(getRandomStatus());
                //System.out.println(deviceEvent.getMacAddress()+"   "+deviceEvent.getStatus());
                System.out.println(deviceEvent.toString());
        }
    };

    final ScheduledFuture<?> beeperHandle =
            scheduler.scheduleAtFixedRate(beeper, 5, 5, MINUTES);

    public  DeviceEvent getDeviceEvent() {
        return deviceEvent;
    }

    String getRandomStatus(){
        Random random = new Random();
        int idx= random.nextInt(3);

        if (idx==0)
            return  "Warning";
        else
        if (idx==1)
            return  "Up";
        else
            return  "Down";
    }
}
