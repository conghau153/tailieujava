package devicemanagement.service;
import devicemanagement.model.Device;
import devicemanagement.model.DeviceEvent;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface DeviceDAO {

    List<Device> getListDevice();

    boolean addDevice(Device device);

    boolean updateDevice(Device device);

    boolean deleteDevice(String id);

    Device getDeviceById(String id);

    Device getDeviceByMacAddress(String macAddress);

    boolean updateEvent(DeviceEvent deviceEvent);
    String getMacAddress();

}