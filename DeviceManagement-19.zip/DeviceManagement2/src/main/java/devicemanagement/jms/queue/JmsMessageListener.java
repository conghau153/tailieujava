package devicemanagement.jms.queue;

import devicemanagement.app.DeviceService;
import devicemanagement.model.Device;

import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

public class JmsMessageListener  implements MessageListener {
    private DeviceService deviceService = new DeviceService();

    public static String status=null;
    public static Device device=null;
    public static String id=null;


    public void onMessage(Message message) {
        MapMessage mapMessage = (MapMessage) message;
        try {
            device = null;
            status= mapMessage.getString("status-X");
            if (("add".equals(status))  ){
                device = new Device(
                        mapMessage.getString("id"),
                        mapMessage.getString("name"),
                        mapMessage.getString("address"),
                        mapMessage.getString("macAddress"),
                        mapMessage.getString("status"),
                        mapMessage.getString("type"),
                        mapMessage.getString("version")
                );
                JmsMessage.latchCountDown();

                //add device
                boolean check = deviceService.add(device);

                if (check){
                    JmsMessageSender.sendMessage(null,"Created","jmsMessage-2");
                }
                else{
                    JmsMessageSender.sendMessage(null,"Error create","jmsMessage-2");
                }

            }else
                if ("delete".equals(status)){
                    id = mapMessage.getString("id");
                    JmsMessage.latchCountDown();
                    //delete
                    boolean check = deviceService.delete(id);

                    if (check){
                        JmsMessageSender.sendMessage(null,"Deleted","jmsMessage-2");
                    }
                    else{
                        JmsMessageSender.sendMessage(null,"Error delete","jmsMessage-2");
                    }
                }
                else{
                    //DeviceRestController.status= mapMessage.getString("status-X");

                    JmsMessage.latchCountDown();
                }
        }  catch (Exception e) {
            e.printStackTrace();
        }
    }
}
