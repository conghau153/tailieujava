package devicemanagement.jms.queue;

import devicemanagement.model.Device;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;

public class JmsMessageSender {
    public static void sendMessage(Object obj, String status, String queueName)
            throws  Exception {

        Connection connection = null;
        try {
            // Producer
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
                    "tcp://localhost:61616");
            connection = connectionFactory.createConnection();
            Session session = connection.createSession(false,
                    Session.AUTO_ACKNOWLEDGE);

            Queue queue = session.createQueue(queueName);

            MessageProducer producer = session.createProducer(queue);
            MapMessage mapMessage= session.createMapMessage();

            mapMessage.setString("status-X",status);
            if (obj!=null){
                if (obj instanceof Device){
                    Device device= (Device) obj;
                    mapMessage.setString("id", device.getId());
                    mapMessage.setString("name",device.getName());
                    mapMessage.setString("address",device.getAddress());
                    mapMessage.setString("macAddress",device.getMacAddress());
                    mapMessage.setString("status",device.getStatus());
                    mapMessage.setString("type",device.getType());
                    mapMessage.setString("version",device.getVersion());
                }else {
                    String id= (String) obj;
                    mapMessage.setString("id",id);
                }
            }


            producer.send(mapMessage);
            session.close();
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }
}
