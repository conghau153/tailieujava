package devicemanagement.app;

import devicemanagement.jms.queue.JmsMessage;



public class JmsAsyncReceiveQueue {

    public static void main(String[] args) throws  Exception {

        JmsMessage asyncReceiveClient = new JmsMessage();
        asyncReceiveClient.receiveMessages("jmsMessage-1",5);
    }


}