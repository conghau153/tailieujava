package devicemanagement.jms;

import devicemanagement.model.Device;
import org.springframework.jms.core.support.JmsGatewaySupport;



public class SpringJmsDeviceSender extends JmsGatewaySupport {
    public void sendMessage(final Device device) {
        //System.out.println("Producer sends " + device);
        getJmsTemplate().convertAndSend(device);
    }
}
