package devicemanagement.jms;

import devicemanagement.model.Device;
import org.springframework.jms.core.support.JmsGatewaySupport;

import javax.jms.JMSException;


public class SpringJmsDeviceReceive extends JmsGatewaySupport {
    public Device receiveMessage() throws JMSException {
       Device device = (Device) getJmsTemplate().receiveAndConvert();

        return device;
    }
}
