package devicemanagement.controller;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import devicemanagement.model.ViewDevice;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class DeviceController {

    @RequestMapping(value = "/login")
    public String login(){
        return "login";
    }

    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
        //get auth user
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }

    @RequestMapping(value = "/Access_Denied")
    @ResponseBody
    public String accesssDenied(Principal user) {
        return "Access Denied";
    }

    @RequestMapping(value = "/listDevice", method = RequestMethod.GET)
    public ModelAndView getAllDevice(){
        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();

        boolean checkAdmin= false;
        String username = null;
        String password = null;
        //get username
        Object auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth!=null){
            Object principal = ((Authentication) auth).getPrincipal();
            if (principal instanceof UserDetails) {
                username= ((UserDetails)principal).getUsername();
                password= ((UserDetails) principal).getPassword();
                Object[] roles= ((UserDetails) principal).getAuthorities().toArray();
                //get role admin
                for (Object role: roles){
                    if ("ROLE_ADMIN".equals(role.toString()))
                        checkAdmin = true;
                }
            }
        }

        if (checkAdmin){
            try {
                String authString = username + ":" + password;
                String authStringEnc = new BASE64Encoder().encode(authString.getBytes());

                Client client = Client.create();

                WebResource webResource = client
                        .resource("http://127.0.0.1:8090/api/devices");

                //send a GET with contentType and Basic Authentication
                ClientResponse response = webResource.accept("application/json;charset=UTF-8")
                        .header("Authorization", "Basic " + authStringEnc)
                        .get(ClientResponse.class);

                //check error or access
                if (response.getStatus() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + response.getStatus());
                }

                //get a array JSONObject
                JSONArray result =  response.getEntity(JSONArray.class);
                for (int i=0; i<result.length();i++){
                    JSONObject json = (JSONObject) result.get(i);

                    //convert JSONObject to json
                    ViewDevice viewDevice = convertToViewDevice(json);
                    listViewDevice.add(viewDevice);
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }


        modelAndView.addObject("user",username);
        modelAndView.addObject("list",listViewDevice);
        return modelAndView;
    }

    @RequestMapping(value = "/device/{id}", method = RequestMethod.GET)
    public ModelAndView getDeviceById(@PathVariable String id){
        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();
        boolean checkAdmin= false;
        String username = null;
        String password = null;

        //get username, password and check role admin
        Object auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth!=null){
            Object principal = ((Authentication) auth).getPrincipal();
            if (principal instanceof UserDetails) {
                username= ((UserDetails)principal).getUsername();
                password= ((UserDetails) principal).getPassword();
                Object[] roles= ((UserDetails) principal).getAuthorities().toArray();
                for (Object role: roles){
                    if ("ROLE_ADMIN".equals(role.toString()))
                        checkAdmin = true;
                }
            }
        }
        if (checkAdmin){
            try {
                String url = "http://127.0.0.1:8090/api/devices/" + id;

                String authString = username + ":" + password;
                String authStringEnc = new BASE64Encoder().encode(authString.getBytes());

                Client client = Client.create();
                //send a GET  Id with url, contentType, basic authentication
                WebResource webResource = client.resource(url);
                ClientResponse resp = webResource.accept("application/json;charset=UTF-8")
                        .header("Authorization", "Basic " + authStringEnc)
                        .get(ClientResponse.class);

                if (resp.getStatus() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + resp.getStatus());
                }
                //get JSONObject
                JSONObject obj = resp.getEntity(JSONObject.class);
                ViewDevice viewDevice= convertToViewDevice(obj);
                listViewDevice.add(viewDevice);
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        modelAndView.addObject("list",listViewDevice);
        return modelAndView;
    }

    /**
     * convert json to viewDevice
     * @param jsonObject
     * @return a viewDevice
     */
    ViewDevice convertToViewDevice(JSONObject jsonObject){
        ViewDevice viewDevice=null;
        try{
            String id = jsonObject.getString("id");
            String name = jsonObject.getString("name");
            String address = jsonObject.getString("address");
            String macAddress = jsonObject.getString("macAddress");
            String status = jsonObject.getString("status");
            String type = jsonObject.getString("type");
            String version = jsonObject.getString("version");

            viewDevice= new ViewDevice(id,name,address,macAddress,status,type,version);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return viewDevice;
    }

}
