package devicemanagement.controller;


import devicemanagement.jms.SpringJmsDeviceReceive;
import devicemanagement.jms.SpringJmsDeviceSender;
import devicemanagement.model.Device;

import org.apache.activemq.broker.BrokerFactory;
import org.apache.activemq.broker.BrokerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import java.net.URI;

@Controller
public class HomeController {

    BrokerService broker = null;

    @Autowired
    SpringJmsDeviceReceive springJmsDeviceReceive;

    @Autowired
    SpringJmsDeviceSender springJmsDeviceSender;

    @RequestMapping(value = "/home")
    public String home(){
        Device result= null;

        try {
//            broker = BrokerFactory.createBroker(new URI(
//                    "broker:(tcp://localhost:61616)"));
//            broker.start();

            springJmsDeviceSender.sendMessage(
                    new Device(
                            "5bebe73bd230b7587da8d12",
                            "switch95",
                            "10.1.2.95",
                            "eB:e7:32:9B:7a:c0",
                            "Up",
                            "0S6850E-C24",
                            "6.4.6.361"
                    ));

            // result= springJmsDeviceReceive.receiveMessage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "home";
    }

    @RequestMapping(value = "/newdevice")
    @ResponseBody
    public Object newDevice(){
        Object result= null;
        try {

            result= springJmsDeviceReceive.receiveMessage();
            //broker.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
