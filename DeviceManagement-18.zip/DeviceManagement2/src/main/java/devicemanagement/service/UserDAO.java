package devicemanagement.service;

import devicemanagement.model.User;


public interface UserDAO {
    User getUser(String username);
    boolean isExitsUser(User user);
}
