package devicemanagement.app;

import devicemanagement.jms.queue.JmsMessage;

import java.net.URISyntaxException;


public class JmsAsyncReceiveQueue {

    public static void main(String[] args) throws URISyntaxException, Exception {

        JmsMessage asyncReceiveClient = new JmsMessage();
        asyncReceiveClient.receiveMessages("jmsMessage-1",5);
    }


}