package devicemanagement.controller;

import devicemanagement.jms.queue.JmsMessage;
import devicemanagement.jms.queue.JmsMessageListener;
import devicemanagement.jms.queue.JmsMessageSender;
import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import devicemanagement.model.ViewDevice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.http.*;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


public class TestDeviceRestController {

    private MockMvc mockMvcDeviceRestController;

    @Mock
    private DeviceDAO deviceDAO;


    @InjectMocks
    private DeviceRestController deviceRestController;

    Device device = new Device();
    Device device1 = new Device();

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        mockMvcDeviceRestController = MockMvcBuilders
                .standaloneSetup(deviceRestController)
                .build();

        device.setId("5be15357f9d8487d938669a7");
        device.setName("vxTarget");
        device.setAddress("10.1.2.125");
        device.setMacAddress("eB:e7:32:de:f0:9B");
        device.setStatus("Up");
        device.setType("0S6450-U245");
        device.setVersion("6.7.2.107");


        device1.setId("5be15364f9d8487d938669a10");
        device1.setName("DCD-2");
        device1.setAddress("10.1.3.95");
        device1.setMacAddress("eB:f2:32:f3:a3:9h");
        device1.setStatus("Up");
        device1.setType("0S5686200");
        device1.setVersion("8.1.2.1");
    }

    @Test
    public void getAllDeviceTest() throws Exception {
        List<Device> devices = Arrays.asList(device1);
        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();

        when(deviceDAO.getListDevice()).thenReturn(devices);

        for (Device device: devices){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }

        mockMvcDeviceRestController.perform(get("/api/devices"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].id", is("5be15364f9d8487d938669a10")))
                .andExpect(jsonPath("$[0].name", is("DCD-2")))
                .andExpect(jsonPath("$[0].address", is("10.1.3.95")))
                .andExpect(jsonPath("$[0].macAddress", is("eB:f2:32:f3:a3:9h")))
                .andExpect(jsonPath("$[0].status", is("Up")))
                .andExpect(jsonPath("$[0].type", is("0S5686200")))
                .andExpect(jsonPath("$[0].version", is("8.1.2.1")))
        ;

        verify(deviceDAO, times(1)).getListDevice();
        verifyNoMoreInteractions(deviceDAO);
    }

    @Test
    public void getDeviceByIdTest_success() throws Exception {
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);
        mockMvcDeviceRestController.perform(get("/api/devices/{id}", "5be15357f9d8487d938669a7"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json;charset=UTF-8"))
                .andExpect(jsonPath("$.id", is("5be15357f9d8487d938669a7")))
                .andExpect(jsonPath("$.name", is("vxTarget")))
                .andExpect(jsonPath("$.address", is("10.1.2.125")))
                .andExpect(jsonPath("$.macAddress", is("eB:e7:32:de:f0:9B")))
                .andExpect(jsonPath("$.status", is("Up")))
                .andExpect(jsonPath("$.type", is("0S6450-U245")))
                .andExpect(jsonPath("$.version", is("6.7.2.107")))
                ;

        verify(deviceDAO, times(1)).getDeviceById("5be15357f9d8487d938669a7");
        verifyNoMoreInteractions(deviceDAO);
    }


    @Test
    public void testAddDevice_success() throws Exception {
        ViewDevice viewDevice = new ViewDevice(device);

        mockMvcDeviceRestController.perform(
                post("/api/devices")
                        .contentType("application/json;charset=UTF-8")
                        .content(asJsonString(viewDevice))
                )
                .andExpect(status().isOk())
                ;

        JmsMessageSender.sendMessage(device,"add","jmsMessage-1");
        JmsMessage asyncReceiveClient = new JmsMessage();
        asyncReceiveClient.receiveMessages("jmsMessage-1",1);

        String messageStatus= JmsMessageListener.status;
        Device messageDevice= JmsMessageListener.device;
        assertEquals("add",messageStatus);
        assertEquals(device,messageDevice);

        asyncReceiveClient.receiveMessages("jmsMessage-2",1);

    }

    @Test
    public void testUpdateDevice_success() throws Exception {
        when(deviceDAO.getDeviceById(device.getId())).thenReturn(device);
        when(deviceDAO.updateDevice(device)).thenReturn(true);

        mockMvcDeviceRestController.perform(
                put("/api/devices/{id}", device.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(device)))
                .andExpect(status().isOk());

        verify(deviceDAO, times(1)).getDeviceById(device.getId());
        verify(deviceDAO, times(1)).updateDevice(device);
        verifyNoMoreInteractions(deviceDAO);
    }

    @Test
    public void testDeleteDevice() throws Exception {
        when(deviceDAO.getDeviceById(device.getId())).thenReturn(device);
        when(deviceDAO.deleteDevice(device)).thenReturn(true);

        mockMvcDeviceRestController.perform(
                delete("/api/devices/{id}", device.getId()))
                .andExpect(status().isOk());

        JmsMessageSender.sendMessage(device.getId(),"delete","jmsMessage-1");
        JmsMessage asyncReceiveClient = new JmsMessage();
        asyncReceiveClient.receiveMessages("jmsMessage-1",1);

        String messageStatus= JmsMessageListener.status;
        String id= JmsMessageListener.id;

        assertEquals("delete",messageStatus);
        assertEquals(device.getId(),id);

        asyncReceiveClient.receiveMessages("jmsMessage-2",1);

    }


    public static String asJsonString(final Object obj) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
