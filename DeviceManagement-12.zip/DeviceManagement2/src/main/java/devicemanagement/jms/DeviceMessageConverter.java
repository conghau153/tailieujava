package devicemanagement.jms;


import devicemanagement.model.Device;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

public class DeviceMessageConverter implements MessageConverter{

    public Message toMessage(Object object, Session session)
            throws JMSException, MessageConversionException {
        Device device = (Device) object;
        MapMessage message = session.createMapMessage();
        message.setString("id", device.getId());
        message.setString("name", device.getName());
        message.setString("address", device.getAddress());
        message.setString("macAddress", device.getMacAddress());
        message.setString("status", device.getStatus());
        message.setString("type", device.getType());
        message.setString("version", device.getVersion());

        return message;
    }

    public Object fromMessage(Message message) throws JMSException,
            MessageConversionException {
        MapMessage mapMessage = (MapMessage) message;
        Device device = new Device(
                mapMessage.getString("id"),
                mapMessage.getString("name"),
                mapMessage.getString("address"),
                mapMessage.getString("macAddress"),
                mapMessage.getString("status"),
                mapMessage.getString("type"),
                mapMessage.getString("version")
        );
        return device;
    }

}
