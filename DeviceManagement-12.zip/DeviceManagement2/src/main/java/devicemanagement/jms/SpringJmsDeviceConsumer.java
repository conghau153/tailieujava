package devicemanagement.jms;

import devicemanagement.model.Device;
import org.springframework.jms.core.support.JmsGatewaySupport;

import javax.jms.JMSException;
import java.util.Map;

public class SpringJmsDeviceConsumer extends JmsGatewaySupport {
    public Device receiveMessage() throws JMSException {
        Map map = (Map) getJmsTemplate().receiveAndConvert();
        Device device = new Device(
                (String) map.get("id"),
                (String) map.get("name"),
                (String) map.get("address"),
                (String) map.get("macAddress"),
                (String) map.get("status"),
                (String) map.get("type"),
                (String) map.get("version")
        );
        return device;
    }
}
