package devicemanagement.jms;

import devicemanagement.model.Device;
import org.springframework.jms.core.support.JmsGatewaySupport;

import java.util.HashMap;
import java.util.Map;

public class SpringJmsDeviceProducer extends JmsGatewaySupport {
    public void sendMessage(final Device device) {
        System.out.println("Producer sends " + device);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", device.getId());
        map.put("name", device.getName());
        map.put("address", device.getAddress());
        map.put("macAddress", device.getMacAddress());
        map.put("status", device.getStatus());
        map.put("type", device.getType());
        map.put("version", device.getVersion());

        getJmsTemplate().convertAndSend(map);
    }
}
