package devicemanagement.service;

import devicemanagement.model.User;

public interface UserService {
    User getUser(String username);
    boolean isExitsUser(User user);
}
