package devicemanagement.service;


import devicemanagement.model.Device;
import devicemanagement.model.Role;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import devicemanagement.model.User;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class TestDeviceService {
    //use mock test DeviceService
    @Mock
    static DeviceService deviceService;

    @Mock
    static UserService userService;

    @Mock
    static RoleService roleService;

    static Device device1, device2, device3, device4;

    static User user;

    static Role role;

    @Before
    public void init(){
        device1= new Device();
        device1.setId("5be15357f9d8487d938669a7");
        device1.setName("vxTarget");
        device1.setAddress("10.1.2.125");
        device1.setMacAddress("eB:e7:32:de:f0:9B");
        device1.setStatus("Up");
        device1.setType("0S6450-U245");
        device1.setVersion("6.7.2.107");

        device2= new Device();
        device2.setId("5be15364f9d8487d938669a8");
        device2.setName("ABC");
        device2.setAddress("10.1.3.5");
        device2.setMacAddress("eB:f2:32:gd:f0:9B");
        device2.setStatus("Up");
        device2.setType("0S6450-U245");
        device2.setVersion("6.7.2.5");

        device3= new Device();
        device3.setId("5be15364f9d8487d9386578a8");
        device3.setName("BDE");
        device3.setAddress("10.1.2.16");
        device3.setMacAddress("eB:f2:32:gd:h1:g0");
        device3.setStatus("Warning");
        device3.setType("0S645056-23");
        device3.setVersion("7.4.2.17");

        device4= new Device();
        device4.setId("5be15364f9d8487d938669a10");
        device4.setName("DCD-2");
        device4.setAddress("10.1.3.95");
        device4.setMacAddress("eB:f2:32:f3:a3:9h");
        device4.setStatus("Up");
        device4.setType("0S5686200");
        device4.setVersion("8.1.2.1");

        user= new User();
        user.setId("a2f4d1re41f2r42f1411");
        user.setUsername("admin");
        user.setPassword("admin");

        role= new Role();
        role.setId("1241d541e414214da1s1");
        role.setUserId("a2f4d1re41f2r42f1411");
        role.setRole("ROLE_ADMIN");

        when(deviceService.getDeviceById("5be15364f9d8487d938669a8")).thenReturn(device2);
        when(userService.getUser("admin")).thenReturn(user);
        when(roleService.getRoleUser("a2f4d1re41f2r42f1411")).thenReturn(Arrays.asList(role));
        when(deviceService.getDeviceByMacAddress("eB:f2:32:gd:f0:9B")).thenReturn(device2);

    }

    @Test
    public void getListDeviceTest(){
        List<Device> list_device = new ArrayList<Device>(Arrays.asList(new Device[]{device1, device2, device3}));
        when(deviceService.getListDevice()).thenReturn(list_device);

        //check size list_device
        assertEquals(3,deviceService.getListDevice().size());
        assertEquals(list_device,deviceService.getListDevice());
    }

    @Test
    public void addDeviceTest(){
        List<Device> listBefore = new ArrayList<Device>(Arrays.asList(device1, device2, device3));
        List<Device> listAfter = new ArrayList<Device>(Arrays.asList(device1, device2, device3));

        when(deviceService.addDevice(device4)).thenReturn(listAfter.add(device4));

        assertEquals(true,deviceService.addDevice(device4));
        assertEquals(listBefore.size()+1,listAfter.size());
    }

    @Test
    public void getDeviceByIdTest(){
        assertEquals(device2,deviceService.getDeviceById("5be15364f9d8487d938669a8"));
    }
    @Test
    public void getUserTest(){
        assertEquals(user, userService.getUser("admin"));
    }

    @Test
    public void getRoleUserTest(){
        assertEquals(Arrays.asList(role),roleService.getRoleUser("a2f4d1re41f2r42f1411"));
    }

    @Test
    public void getDeviceByMacAddressTest(){
        //check result
        assertEquals(device2,deviceService.getDeviceByMacAddress("eB:f2:32:gd:f0:9B"));
    }

    @Test
    public void updateDeviceTest(){
        List<Device> list_device = new ArrayList<Device>(Arrays.asList(new Device[]{device1, device2, device3}));

        Device deviceUpdate = new Device();
        deviceUpdate.setId("5be15364f9d8487d9386578a8");
        deviceUpdate.setName("BDE-X");
        deviceUpdate.setAddress("10.1.2.16");
        deviceUpdate.setMacAddress("eB:f2:32:gd:h1:g0");
        deviceUpdate.setStatus("Warning");
        deviceUpdate.setType("0S645056-23");
        deviceUpdate.setVersion("7.4.2.18");

        //set mock updateDevice
        when(deviceService.updateDevice(device3)).thenReturn(update(deviceUpdate,device3));

        //check
        assertEquals(true,deviceService.updateDevice(device3));
        assertEquals(deviceUpdate,list_device.get(2));
    }
    @Test
    public void deleteDeviceTest(){
        List<Device> listBefore = new ArrayList<Device>(Arrays.asList(new Device[]{device1, device2, device3}));
        List<Device> listAfter = new ArrayList<Device>(Arrays.asList(new Device[]{device1, device2, device3}));
        //set a mock deleteDevice by macAddress return size list_device
        when(deviceService.deleteDevice(device2)).thenReturn(listAfter.remove(device2));

        //check result
        assertEquals(true,deviceService.deleteDevice(device2));
        assertEquals(listBefore.size()-1,listAfter.size());
    }
    boolean update(Device device1, Device device2){
        if (device1.getId()== device2.getId()){
            device2.setName(device1.getName());
            device2.setAddress(device1.getAddress());
            device2.setType(device1.getType());
            device2.setVersion(device1.getVersion());
            return  true;
        }else{
            return false;
        }
    }

}
