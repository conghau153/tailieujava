package devicemanagement.controller;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import devicemanagement.custom.CustomUserDetailsService;
import devicemanagement.model.User;
import devicemanagement.model.ViewDevice;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DeviceControllerTest {

    @InjectMocks
    private DeviceController deviceController;


    User user= new User();

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        user.setId("12541df1s4f112");
        user.setUsername("admin");
        user.setPassword("admin");

        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));

        org.springframework.security.core.userdetails.User userDetails =
            new org.springframework.security.core.userdetails.User(
                    user.getUsername(),
                    user.getPassword(),
                    true, true, true, true,
                    authorities);

        Authentication auth = new UsernamePasswordAuthenticationToken(userDetails,null);
        SecurityContextHolder.getContext().setAuthentication(auth);

    }

    @Test
    public void TestLogin(){
        assertEquals("login", deviceController.login());
    }

    @Test
    public void TestAccessDenied(){
        assertEquals("Access Denied",deviceController.accessDenied());
    }

    @Test
    public void TestLogout() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        assertEquals("redirect:/login?logout",deviceController.logout(request,response));
    }

    @Test
    public void TestGetAllDevicesClient(){


        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();

        modelAndView.addObject("user",null);
        modelAndView.addObject("list",listViewDevice);
        deviceController.getAllDeviceByClient();
    }

}
