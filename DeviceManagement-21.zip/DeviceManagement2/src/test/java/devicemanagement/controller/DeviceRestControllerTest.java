package devicemanagement.controller;

import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.junit.Before;
import org.junit.Test;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import devicemanagement.model.ViewDevice;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DeviceRestControllerTest {

    private MockMvc mockMvc;

    @Mock
    private DeviceDAO deviceDAO;

    @InjectMocks
    private DeviceRestController deviceRestController;

    Device device = new Device();
    Device device1 = new Device();

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders
                .standaloneSetup(deviceRestController)
                .build();

        device.setId("5be15357f9d8487d938669a7");
        device.setName("vxTarget");
        device.setAddress("10.1.2.125");
        device.setMacAddress("eB:e7:32:de:f0:9B");
        device.setStatus("Up");
        device.setType("0S6450-U245");
        device.setVersion("6.7.2.107");


        device1.setId("5be15364f9d8487d938669a10");
        device1.setName("DCD-2");
        device1.setAddress("10.1.3.95");
        device1.setMacAddress("eB:f2:32:f3:a3:9h");
        device1.setStatus("Up");
        device1.setType("0S5686200");
        device1.setVersion("8.1.2.1");
    }

    @Test
    public void getAllDeviceTest() {
        List<Device> devices = new ArrayList<Device>();
        devices.add(device1);

        List<ViewDevice> viewDevices = new ArrayList<ViewDevice>();
        viewDevices.add(new ViewDevice(device1));

        when(deviceDAO.getListDevice()).thenReturn(devices);
        assertEquals( viewDevices, deviceRestController.getAllDevice());
    }

    @Test
    public void getDeviceByIdTest() {
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a2")).thenReturn(null);
        ViewDevice viewDevice= new ViewDevice(device);

        assertEquals(viewDevice, deviceRestController.getDeviceById("5be15357f9d8487d938669a7"));
        assertEquals("Not Found Device", deviceRestController.getDeviceById("5be15357f9d8487d938669a2"));
    }

    @Test
    public void getDeviceByMacAddressTest() {
        ViewDevice viewDevice= new ViewDevice(device);
        when(deviceDAO.getDeviceByMacAddress("eB:e7:32:de:f0:9B")).thenReturn(device);
        when(deviceDAO.getDeviceByMacAddress("eB:e7:32:de:f0:9A")).thenReturn(null);


        assertEquals(viewDevice, deviceRestController.getDeviceByMacAddress("eB:e7:32:de:f0:9B"));
        assertEquals("Not Found Device", deviceRestController.getDeviceByMacAddress("eB:e7:32:de:f0:9A"));
    }

    @Test
    public void testAddDeviceTest()  {
        ViewDevice viewDevice = new ViewDevice(device);
        when(deviceDAO.addDevice(device)).thenReturn(true);

        ViewDevice viewDevice1 = new ViewDevice(device1);
        when(deviceDAO.addDevice(device1)).thenReturn(false);

        assertEquals("Created",deviceRestController.addDevice(viewDevice));
        assertEquals("Error create",deviceRestController.addDevice(viewDevice1));
    }

    @Test
    public void testUpdateDevice() {

        ViewDevice viewDevice= new ViewDevice(device);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a9")).thenReturn(null);
        when(deviceDAO.updateDevice(device)).thenReturn(true);

        assertEquals("Updated!",
                deviceRestController.updateDevice("5be15357f9d8487d938669a7",viewDevice));
        assertEquals("Error update",
                deviceRestController.updateDevice("5be15357f9d8487d938669a7",new ViewDevice()));
        assertEquals("Not Found Device",
                deviceRestController.updateDevice("5be15357f9d8487d938669a9",viewDevice));

    }

    @Test
    public void testDeleteDevice()  {
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a7")).thenReturn(true);
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a9")).thenReturn(false);

        assertEquals("Deleted",deviceRestController.deleteDeviceById("5be15357f9d8487d938669a7"));
        assertEquals("Error delete",deviceRestController.deleteDeviceById("5be15357f9d8487d938669a9"));
    }




}
