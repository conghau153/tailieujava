package devicemanagement.service;

import devicemanagement.controller.DeviceRestController;
import devicemanagement.model.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserDAOImplTest {

    @Mock
    MongoTemplate mongoTemplate;

    @InjectMocks
    private UserDAOImpl userDAO;

    User user= new User();

    @Before
    public void init(){
        user.setId("12541df1s4f112");
        user.setUsername("member");
        user.setPassword("member");
    }

    @Test
    public void getUserTest() {
        when(mongoTemplate.findOne(
                Query.query(Criteria.where("username").is("member")),
                User.class,"user")).thenReturn(user);

        assertEquals(user,userDAO.getUser("member"));
    }
}