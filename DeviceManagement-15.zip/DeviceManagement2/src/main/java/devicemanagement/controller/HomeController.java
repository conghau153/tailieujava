package devicemanagement.controller;


import devicemanagement.jms.queue.consumer.ConsumerMessage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class HomeController {

    public static String status;

    @RequestMapping(value = "/home")
    public String home(){
//        try {
//            JmsProducerSender.sendMessage(
//                    new Device(
//                            "5bebe73bd230b7587da8d12",
//                            "switch95",
//                            "10.1.2.95",
//                            "eB:e7:32:9B:7a:c0",
//                            "Up",
//                            "0S6850E-C24",
//                            "6.4.6.361"
//                    ));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        return "home";
    }

    @RequestMapping(value = "/newdevice")
    @ResponseBody
    public Object newDevice(){
        status=null;
        try {
            ConsumerMessage asyncReceiveClient = new ConsumerMessage();
            asyncReceiveClient.receiveMessages();


            //result= springJmsDeviceReceive.receiveMessage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}
