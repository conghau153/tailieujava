package devicemanagement.jms.queue.consumer;


import devicemanagement.controller.DeviceRestController;
import devicemanagement.jms.queue.consumer.ConsumerMessage;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;


public class ConsumerMessageListener implements MessageListener {
    private Object asyncReceiveQueueClientExample;


    public void onMessage(Message message) {
        // TextMessage textMessage = (TextMessage) message;
        MapMessage mapMessage = (MapMessage) message;
        try {
            //HomeController.status= mapMessage.getString("status-X");

            DeviceRestController.status= mapMessage.getString("status-X");
            System.out.println(DeviceRestController.status);

            ((ConsumerMessage)asyncReceiveQueueClientExample).latchCountDown();
        } catch (JMSException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setAsyncReceiveQueueClientExample(
            Object asyncReceiveQueueClientExample) {
        this.asyncReceiveQueueClientExample = asyncReceiveQueueClientExample;
    }
}
