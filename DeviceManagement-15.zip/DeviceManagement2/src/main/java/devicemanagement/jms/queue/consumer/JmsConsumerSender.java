package devicemanagement.jms.queue.consumer;

import java.net.URISyntaxException;

import javax.jms.*;

import org.apache.activemq.ActiveMQConnectionFactory;

public class JmsConsumerSender {
    public static void sendMessage(String status) throws URISyntaxException, Exception {
        Connection connection = null;
        try {
            // Producer
            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
                    "tcp://localhost:61616");
            connection = connectionFactory.createConnection();
            Session session = connection.createSession(false,
                    Session.AUTO_ACKNOWLEDGE);
            Queue queue = session.createQueue("consumerQueue");
            MessageProducer producer = session.createProducer(queue);
            MapMessage mapMessage= session.createMapMessage();

            mapMessage.setString("status-X",status);

            producer.send(mapMessage);
            session.close();
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
    }
}