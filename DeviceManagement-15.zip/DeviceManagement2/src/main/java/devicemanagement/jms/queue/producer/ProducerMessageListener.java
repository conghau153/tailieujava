package devicemanagement.jms.queue.producer;

import devicemanagement.app.DeviceService;
import devicemanagement.jms.queue.consumer.JmsConsumerSender;
import devicemanagement.model.Device;

import javax.jms.*;
import java.net.URISyntaxException;

public class ProducerMessageListener implements MessageListener {

    private Object asyncReceiveQueueClientExample;

    private DeviceService deviceService = new DeviceService();


    public void onMessage(Message message) {
       // TextMessage textMessage = (TextMessage) message;
        MapMessage mapMessage = (MapMessage) message;
        try {
            //if ("device".equals(mapMessage.getString("status-X"))){
                Device device = new Device(
                        mapMessage.getString("id"),
                        mapMessage.getString("name"),
                        mapMessage.getString("address"),
                        mapMessage.getString("macAddress"),
                        mapMessage.getString("status"),
                        mapMessage.getString("type"),
                        mapMessage.getString("version")
                );
                ((ProducerMessage)asyncReceiveQueueClientExample).latchCountDown();
                if ("delete".equals(mapMessage.getString("status-X"))){
                    //delete
                    boolean check = deviceService.delete(device);
                    System.out.println(device.getName());
                    System.out.println(check);
                    if (check){
                        JmsConsumerSender.sendMessage("Deleted");
                    }
                    else{
                        JmsConsumerSender.sendMessage("Error delete");
                    }
                }else{
                    //create
                    boolean check = deviceService.add(device);
                    System.out.println(device.getName());
                    System.out.println(check);
                    if (check){
                        JmsConsumerSender.sendMessage("Created");
                    }
                    else{
                        JmsConsumerSender.sendMessage("Error create");
                    }
                }

        } catch (JMSException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setAsyncReceiveQueueClientExample(
            Object asyncReceiveQueueClientExample) {
        this.asyncReceiveQueueClientExample = asyncReceiveQueueClientExample;
    }
}