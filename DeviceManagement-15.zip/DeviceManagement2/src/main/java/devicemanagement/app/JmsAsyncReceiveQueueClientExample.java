package devicemanagement.app;

import java.net.URISyntaxException;

import devicemanagement.jms.queue.producer.ProducerMessage;

public class JmsAsyncReceiveQueueClientExample {

    public static void main(String[] args) throws URISyntaxException, Exception {

        ProducerMessage asyncReceiveClient = new ProducerMessage();
        asyncReceiveClient.receiveMessages();
    }


}