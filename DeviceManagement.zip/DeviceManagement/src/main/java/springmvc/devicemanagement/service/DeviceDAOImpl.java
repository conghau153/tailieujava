package springmvc.devicemanagement.service;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import springmvc.devicemanagement.model.Device;

@Repository
public class DeviceDAOImpl implements DeviceDAO {
    @Autowired
    private MongoTemplate mongoTemplate;

    public static final String COLLECTIONNAME = "device";

    //implement addDevice method return size list device after insert device
    public int addDevice(Device device) {
        //get collection
        if (!mongoTemplate.collectionExists(Device.class)) {
            mongoTemplate.createCollection(Device.class);
        }
        //device.setId(UUID.randomUUID().toString());
        mongoTemplate.insert(device, COLLECTIONNAME);
        return mongoTemplate.findAll(Device.class, COLLECTIONNAME).size();
    }
    //implement a getListDevice method return list device
    public List<Device> getListDevice() {
        return mongoTemplate.findAll(Device.class, COLLECTIONNAME);
    }

    //implement a deleteDevice method return size list device after delete device
    public int deleteDevice(String macAddress) {
        //find a device by macAddress
        Device deviceDelete= mongoTemplate.findOne(Query.query(Criteria.where("macAddress").is(macAddress)), Device.class,COLLECTIONNAME);

        //remove device
        mongoTemplate.remove(deviceDelete, COLLECTIONNAME);
        return mongoTemplate.findAll(Device.class, COLLECTIONNAME).size();
    }

    //implement a updateDevice method
    public Device updateDevice(Device device) {
        //find and delete device mongoDB by macAddress device in
        Device deviceDelete= mongoTemplate.findOne(Query.query(Criteria.where("macAddress").is(device.getMacAddress())), Device.class,COLLECTIONNAME);
        mongoTemplate.remove(deviceDelete, COLLECTIONNAME);

        //update device to mongoDB
        mongoTemplate.insert(device, COLLECTIONNAME);
        return  device;
    }

    //implement a getDeviceByMacAddress return a device by macAddress
    public Device getDeviceByMacAddress(String macAddress) {
        return mongoTemplate.findOne(Query.query(Criteria.where("macAddress").is(macAddress)), Device.class,COLLECTIONNAME);
    }
}