package springmvc.devicemanagement.service;
import springmvc.devicemanagement.model.Device;

import java.util.List;

public interface DeviceDAO {
    int addDevice(Device device);
    List<Device> getListDevice();
    int deleteDevice(String macAddress);
    Device updateDevice(Device device);
    //public Device getDevice(String id);
    Device getDeviceByMacAddress(String macAddress);
}