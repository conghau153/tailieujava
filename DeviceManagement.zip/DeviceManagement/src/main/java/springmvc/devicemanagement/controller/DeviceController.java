package springmvc.devicemanagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.service.DeviceDAO;

import java.util.List;


@Controller
public class DeviceController {
    @Autowired
    private DeviceDAO deviceDao;

    String error="";

    @RequestMapping("/listDevice")
    public ModelAndView listDevice(){
        //write the code to get all deviceloyees from DAO
        List<Device> listDevice=deviceDao.getListDevice();
        return new ModelAndView("listDevice","list",listDevice);
    }

    @RequestMapping("/formDevice")
    public ModelAndView showFormDevice(){
        //command is a reserved request attribute name, now use <form> tag to show object data
        ModelAndView model = new ModelAndView("formDevice");
        model.addObject("command",new Device());

        //set a message error in form device
        model.addObject("msg",error);
        if (!"".equals(error)) error="";

        return model;
        //return new ModelAndView("deviceform","command",new Device());
    }

    @RequestMapping(value="/save",method = RequestMethod.POST)
    public ModelAndView saveDevice(@ModelAttribute("device") Device device){
        //check MAC Address in mongoDB
        Device devi= deviceDao.getDeviceByMacAddress(device.getMacAddress());
        //check form add new device
        Boolean check = "".equals(device.getAddress())
                || "".equals(device.getMacAddress())
                || "".equals(device.getName())
                || "".equals(device.getType())
                || "".equals(device.getVersion())
                || (device.getName().length()>128)
                || (device.getType().length()>64)
                || (device.getVersion().length()>64);


        if (devi!=null || check ){
            error= "Can not add new device ";
            //return new ModelAndView("redirect:/deviceform");
            return showFormDevice();
        }else{
            deviceDao.addDevice(device);
            return new ModelAndView("redirect:/listDevice");//will redirect to listDevice request mapping
        }

    }


    @RequestMapping(value="/editDevice/{macAddress}")
    public ModelAndView editDevice(@PathVariable String macAddress){
        //get a device by macAddress
        Device device=deviceDao.getDeviceByMacAddress(macAddress);

        //return device to editFormDevice
        return new ModelAndView("editFormDevice","command",device);
    }



    @RequestMapping(value="/editSave",method = RequestMethod.POST)
    public ModelAndView editSaveDevice(@ModelAttribute("device") Device device){
        //update device
        deviceDao.updateDevice(device);

        return new ModelAndView("redirect:/listDevice");
    }


    @RequestMapping(value="/deleteDevice/{macAddress}",method = RequestMethod.GET)
    public ModelAndView deleteDevice(@PathVariable String macAddress){
        //delete device by macAddress
        deviceDao.deleteDevice(macAddress);
        return new ModelAndView("redirect:/listDevice");
    }
}