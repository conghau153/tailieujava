package springmvc.devicemanagement.controller;



import org.junit.Before;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.context.ContextConfiguration;

import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.service.DeviceDAO;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;


@ContextConfiguration("file:my-context-file.xml")
@RunWith(MockitoJUnitRunner.class)
public class TestController {
    @Mock
    DeviceDAO deviceDAO;

    List<Device> listDevice = new ArrayList<Device>();
    Device device= new Device();
    Device device1= new Device();
    Device device2= new Device();

    @Before
    public void setup()
    {
        // this must be called for the @Mock annotations above to be processed.
        MockitoAnnotations.initMocks( this );

        //set a device
        device.setId("5be15357f9d8487d938669a7");
        device.setName("vxTarget");
        device.setAddress("10.1.2.125");
        device.setMacAddress("eB:e7:32:de:f0:9B");
        device.setStatus("Up");
        device.setType("0S6450-U245");
        device.setVersion("6.7.2.107");

        device2.setId("5be15364f9d8487d9386578a8");
        device2.setName("BDE");
        device2.setAddress("10.1.2.16");
        device2.setMacAddress("eB:f2:32:gd:h1:g0");
        device2.setStatus("Warning");
        device2.setType("0S645056-23");
        device2.setVersion("7.4.2.17");

        device1.setId("5be15364f9d8487d938669a10");
        device1.setName("DCD-2");
        device1.setAddress("10.1.3.95");
        device1.setMacAddress("eB:f2:32:f3:a3:9h");
        device1.setStatus("Up");
        device1.setType("0S5686200");
        device1.setVersion("8.1.2.1");

        listDevice.add(device1);
        listDevice.add(device2);
    }

    @Test
    public void ListDeviceTest()
    {
        // setup mock device list
        when( deviceDAO.getListDevice()).thenReturn( listDevice);

        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();

        //set a deviceDao
        ReflectionTestUtils.setField( controller, "deviceDao", deviceDAO);

        // call the method under test
        ModelAndView mav = controller.listDevice();

        // review the results.
        assertEquals( listDevice, mav.getModel().get( "list" ));
        assertEquals( "listDevice", mav.getViewName());
    }

    @Test
    public void showFormDeviceTest(){
        Device deviceNew = new Device();

        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();

        // call the method under test
        ModelAndView mav = controller.showFormDevice();

        //get a device form
        Device deviceForm= (Device) mav.getModel().get("command");

        //check results
        assertEquals(deviceNew.getName(),deviceForm.getName());
        assertEquals(deviceNew.getMacAddress(),deviceForm.getMacAddress());
        assertEquals(deviceNew.getAddress(),deviceForm.getAddress());
        assertEquals(deviceNew.getType(),deviceForm.getType());
        assertEquals(deviceNew.getVersion(),deviceForm.getVersion());
        assertEquals(deviceNew.getStatus(),deviceForm.getStatus());

        assertEquals("formDevice",mav.getViewName());
    }

    @Test
    public void saveDeviceTest(){
        //set mock addDevice
        when(deviceDAO.addDevice(device)).thenReturn(3);

        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();
        ReflectionTestUtils.setField( controller, "deviceDao", deviceDAO);

        // call the method under test
        ModelAndView mav = controller.saveDevice(device);

        //check result
        assertEquals(3,deviceDAO.addDevice(device));
        assertEquals( "redirect:/listDevice", mav.getViewName());
    }

    @Test
    public void editDeviceTest(){
        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();

        //set a deviceDao using editDevice method
        ReflectionTestUtils.setField(controller,"deviceDao",deviceDAO);

        // call the method under test
        ModelAndView mav = controller.editDevice("eB:f2:32:f3:a3:9h");

        //assertEquals( device1, mav.getModel().get( "command" ));
        assertEquals("editFormDevice",mav.getViewName());
    }

    @Test
    public void editSaveDevice(){
        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();
        ReflectionTestUtils.setField(controller,"deviceDao",deviceDAO);

        // call the method under test
        ModelAndView mav= controller.editSaveDevice(device1);

        //check result
        assertEquals( "redirect:/listDevice", mav.getViewName());
    }

    @Test
    public void deleteDevice(){
        // create an instance of the controller we want to test
        DeviceController controller = new DeviceController();
        ReflectionTestUtils.setField(controller,"deviceDao",deviceDAO);

        // call the method under test
        ModelAndView mav= controller.deleteDevice("eB:f2:32:f3:a3:9h");

        //check result
        assertEquals( "redirect:/listDevice", mav.getViewName());
    }

}
