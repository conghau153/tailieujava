package devicemanagement.jms.queue;

import devicemanagement.app.DeviceService;
import devicemanagement.controller.DeviceRestController;
import devicemanagement.controller.HomeController;

import devicemanagement.model.Device;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import java.net.URISyntaxException;

public class JmsMessageListener  implements MessageListener {
    private DeviceService deviceService = new DeviceService();

    public void onMessage(Message message) {
        // TextMessage textMessage = (TextMessage) message;
        MapMessage mapMessage = (MapMessage) message;
        try {
            Device device = null;
            String status= mapMessage.getString("status-X");
            if (("add".equals(status))  ){
                device = new Device(
                        mapMessage.getString("id"),
                        mapMessage.getString("name"),
                        mapMessage.getString("address"),
                        mapMessage.getString("macAddress"),
                        mapMessage.getString("status"),
                        mapMessage.getString("type"),
                        mapMessage.getString("version")
                );
                JmsMessage.latchCountDown();

                //create
                boolean check = deviceService.add(device);
                System.out.println(device.getName());
                System.out.println(check);
                if (check){
                    JmsMessageSender.sendMessage(null,"Created","jmsMessage-2");
                }
                else{
                    JmsMessageSender.sendMessage(null,"Error create","jmsMessage-2");
                }

            }else
                if (("delete".equals(status))){
                    String id = mapMessage.getString("id");
                    //delete
                    boolean check = deviceService.delete(id);

                    System.out.println(check);
                    if (check){
                        JmsMessageSender.sendMessage(null,"Deleted","jmsMessage-2");
                    }
                    else{
                        JmsMessageSender.sendMessage(null,"Error delete","jmsMessage-2");
                    }
                }
                else{
                    HomeController.status= mapMessage.getString("status-X");

                    DeviceRestController.status= mapMessage.getString("status-X");
                    System.out.println(DeviceRestController.status);

                    JmsMessage.latchCountDown();
                }



        } catch (JMSException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
