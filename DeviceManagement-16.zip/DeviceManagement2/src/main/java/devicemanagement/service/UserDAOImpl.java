package devicemanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import devicemanagement.model.User;

@Repository
public class UserDAOImpl implements UserDAO {
    @Autowired
    MongoTemplate mongoTemplate;

    public static final String CollectionUser = "user";

    /**
     * get a user by name from database
     * @param username
     * @return user
     */
    public User getUser(String username) {
        User user= mongoTemplate.findOne(Query.query(Criteria.where("username").is(username)), User.class,"user");
        return user;
    }

    public boolean isExitsUser(User user) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(user.getId()));
        query.addCriteria(Criteria.where("username").is(user.getUsername()));
        query.addCriteria(Criteria.where("password").is(user.getPassword()));

        User userQuery= mongoTemplate.findOne(query, User.class,CollectionUser);
        if (userQuery!=null)
            return true;
        else
            return false;
    }
}
