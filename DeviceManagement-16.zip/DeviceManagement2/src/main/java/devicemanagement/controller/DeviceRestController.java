package devicemanagement.controller;


import devicemanagement.jms.queue.JmsMessage;
import devicemanagement.jms.queue.JmsMessageSender;
import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import devicemanagement.model.ViewDevice;

import javax.jms.*;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    public static String status;

    @Autowired
    DeviceDAO deviceDAO;


     /*---------------- GET ALL DEVICE ------------------------ */
    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    @ResponseBody
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");
        List<Device> listDevice = deviceDAO.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();
        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }

    /*---------------- CREATE DEVICE  ------------------------ */
    @RequestMapping(value="/devices", method = RequestMethod.POST)
    @ResponseBody
    public String addDevice(@RequestBody ViewDevice viewDevice) throws JMSException {
        Device device = viewDevice.convertToDevice();

        status = null;
        try {
            JmsMessageSender.sendMessage(device,"add","jmsMessage-1");

        } catch (Exception e) {
            e.printStackTrace();
        }

        JmsMessage asyncReceiveClient = new JmsMessage();
        try {
            asyncReceiveClient.receiveMessages("jmsMessage-2",1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return status;
    }

    /* ---------------- GET DEVICE BY ID ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
    @ResponseBody
    public  Object getDeviceById(@PathVariable String id) {
        Device device = deviceDAO.getDeviceById(id);
        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }

    /*---------------- GET DEVICE BY MAC ADDRESS ------------------------ */
    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
    @ResponseBody
    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
        Device device = deviceDAO.getDeviceByMacAddress(macAddress);

        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }


    /*---------------- DELETE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteDeviceById(@PathVariable String id) throws JMSException {


        status = null;
        try {
            JmsMessageSender.sendMessage(id,"delete","jmsMessage-1");
        } catch (Exception e) {
                e.printStackTrace();
        }

        JmsMessage asyncReceiveClient = new JmsMessage();
        try {
                asyncReceiveClient.receiveMessages("jmsMessage-2",1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return status;

    }


    /* ---------------- UPDATE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public String updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {

        Device deviceQuery= deviceDAO.getDeviceById(id);
        if (deviceQuery == null) {
            return "Not Found UserDevice";
        }else{
            //viewDevice.setId(id);
            Device deviceUpdate= viewDevice.convertToDevice();
            boolean ok= deviceDAO.updateDevice(deviceUpdate);
            if (ok)
                return "Updated!";
            else
                return "Error update";
        }
    }
}