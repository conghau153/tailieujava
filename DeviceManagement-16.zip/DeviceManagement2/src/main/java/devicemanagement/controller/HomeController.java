package devicemanagement.controller;


import devicemanagement.custom.CustomUserDetailsService;
import devicemanagement.jms.queue.JmsMessage;
import devicemanagement.jms.queue.JmsMessageSender;

import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class HomeController {

    public static String status;



    @RequestMapping(value = "/home")
    public String home(){
        //ProducerMessageListener producerMessageListener= new ProducerMessageListener();
        //producerMessageListener.onMessage(null);
        try {
            JmsMessageSender.sendMessage(
                    new Device(
                            "5bebe73bd230b7587da8d12",
                            "switch95",
                            "10.1.2.95",
                            "eB:e7:32:9B:7a:c0",
                            "Up",
                            "0S6850E-C24",
                            "6.4.6.361"
                    ),"delete","jmsMessage-1");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "home";
    }

    @RequestMapping(value = "/newdevice")
    @ResponseBody
    public Object newDevice(){
        status=null;
        try {
            JmsMessage asyncReceiveClient = new JmsMessage();
            asyncReceiveClient.receiveMessages("jmsMessage-2",1);


            //result= springJmsDeviceReceive.receiveMessage();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}
