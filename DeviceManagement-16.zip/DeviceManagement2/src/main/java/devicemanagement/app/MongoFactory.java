package devicemanagement.app;

import com.mongodb.*;


public class MongoFactory {

    //private static Logger log = Logger.getLogger(MongoFactory.class);

    private static MongoClient mongoClient;

    private MongoFactory() { }

    // Returns a mongo instance.
    public static MongoClient getMongo() {
        MongoClient mongoClient=null;
        try {
             mongoClient = new MongoClient("127.0.0.1", 27017);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mongoClient;
    }

    // Fetches the mongo database.
    public static DB getDB(String db_name) {
        return getMongo().getDB(db_name);
    }

    // Fetches the collection from the mongo database.
    public static DBCollection getCollection(String db_name, String db_collection) {
        return getDB(db_name).getCollection(db_collection);
    }
}