package devicemanagement.app;


import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

import devicemanagement.model.Device;
import org.apache.log4j.Logger;
import org.bson.types.ObjectId;


public class DeviceService {
    static String db_name = "deviceManagement", db_collection = "device";
    private static Logger log = Logger.getLogger(DeviceService.class);

    // Add a new user to the mongo database.
    public Boolean add(Device device) {
        boolean output = false;
        log.debug("Adding a new user to the mongo database; Entered user_name is= " + device.getName());
        try {
            DBCollection coll = MongoFactory.getCollection(db_name, db_collection);

            BasicDBObject item = (BasicDBObject) getDBObjectMacAddress(device.getMacAddress());
            if (item == null){
                // Create a new object and add the new user details to this object.
                BasicDBObject doc = new BasicDBObject();
                doc.put("name",device.getName());
                doc.put("address",device.getAddress());
                doc.put("macAddress",device.getMacAddress());
                doc.put("status",device.getStatus());
                doc.put("type",device.getType());
                doc.put("version",device.getVersion());

                // Save a new device to the mongo collection.
                coll.insert(doc);
                output = true;
            }
        } catch (Exception e) {
            output = false;
            log.error("An error occurred while saving a new user to the mongo database", e);
        }
        return output;
    }
    // Delete a user from the mongo database.
    public Boolean delete(String id) {
        boolean output = false;
        log.debug("Deleting an existing user from the mongo database;" );
        try {
            DBCollection coll = MongoFactory.getCollection(db_name, db_collection);

            // Fetching the required user from the mongo database.
            BasicDBObject item = (BasicDBObject) getDBObject(id);

            // Deleting the selected user from the mongo database.
            if (item!=null){
                coll.remove(item);
                output = true;
            }

        } catch (Exception e) {
            output = false;
            log.error("An error occurred while deleting an existing user from the mongo database", e);
        }
        return output;
    }

    // Fetching a particular record from the mongo database.
    private DBObject getDBObject(String id) {
        DBCollection coll = MongoFactory.getCollection(db_name, db_collection);

        // Fetching the record object from the mongo database.
        DBObject where_query = new BasicDBObject();

        // Put the selected user_id to search.
        where_query.put("_id", new ObjectId(id));
        //where_query.put("name", device.getName());

        DBObject dbObject=coll.findOne(where_query);

        return dbObject;
    }
    private DBObject getDBObjectMacAddress(String macAddress) {
        DBCollection coll = MongoFactory.getCollection(db_name, db_collection);

        // Fetching the record object from the mongo database.
        DBObject where_query = new BasicDBObject();

        where_query.put("macAddress", macAddress);

        DBObject dbObject=coll.findOne(where_query);

        return dbObject;
    }

}
