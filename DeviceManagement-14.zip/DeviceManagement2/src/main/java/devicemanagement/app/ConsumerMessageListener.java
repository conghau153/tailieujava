package devicemanagement.app;

import devicemanagement.model.Device;


import javax.jms.*;
import java.net.URISyntaxException;


public class ConsumerMessageListener implements MessageListener {

    private Object asyncReceiveQueueClientExample;

    public void onMessage(Message message) {
       // TextMessage textMessage = (TextMessage) message;
        MapMessage mapMessage = (MapMessage) message;
        try {
            //if ("device".equals(mapMessage.getString("status-X"))){
                Device device = new Device(
                        mapMessage.getString("id"),
                        mapMessage.getString("name"),
                        mapMessage.getString("address"),
                        mapMessage.getString("macAddress"),
                        mapMessage.getString("status"),
                        mapMessage.getString("type"),
                        mapMessage.getString("version")
                );
                (( JmsAsyncReceiveQueueClientExample)asyncReceiveQueueClientExample).latchCountDown();
                System.out.println(device.getId());
                JmsProducerQueueClient.sendMessage("Received");

        } catch (JMSException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setAsyncReceiveQueueClientExample(
            Object asyncReceiveQueueClientExample) {
        this.asyncReceiveQueueClientExample = asyncReceiveQueueClientExample;
    }
}