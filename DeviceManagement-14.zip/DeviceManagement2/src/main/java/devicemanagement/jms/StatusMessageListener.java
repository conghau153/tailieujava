package devicemanagement.jms;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

public class StatusMessageListener implements MessageListener {
    public void onMessage(Message message) {
        MapMessage mapMessage = (MapMessage) message;
        try {
            String status= mapMessage.getString("status-X");
            System.out.println(status);

        } catch (JMSException e) {
            e.printStackTrace();
        }

    }
}
