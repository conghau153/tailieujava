package devicemanagement.jms;

import org.springframework.jms.core.support.JmsGatewaySupport;



public class SpringJmsDeviceSender extends JmsGatewaySupport {
    public void sendMessage(final Object obj) {
        //System.out.println("Producer sends " + device);
        getJmsTemplate().convertAndSend(obj);
    }
}
