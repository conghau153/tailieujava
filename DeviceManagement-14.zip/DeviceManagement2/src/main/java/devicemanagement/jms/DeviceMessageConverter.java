package devicemanagement.jms;


import devicemanagement.model.Device;
import devicemanagement.model.User;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;


import javax.jms.*;
import java.util.Map;

public class DeviceMessageConverter implements MessageConverter{

    public Message toMessage(Object object, Session session)
            throws JMSException, MessageConversionException {

        MapMessage message =  session.createMapMessage();

        if (object instanceof Device){
            Device device = (Device) object;
            message.setString("status-X","device");

            message.setString("id", device.getId());
            message.setString("name", device.getName());
            message.setString("address", device.getAddress());
            message.setString("macAddress", device.getMacAddress());
            message.setString("status", device.getStatus());
            message.setString("type", device.getType());
            message.setString("version", device.getVersion());
        }else{
            String status= (String) object;
            //message.setInt("size",1);
            message.setString("status-X",status);
        }
        return message;
    }

    public Object fromMessage(Message message) throws JMSException,
            MessageConversionException {
        MapMessage mapMessage = (MapMessage) message;

        if ("device".equalsIgnoreCase(mapMessage.getString("status-X"))){
            Device device = new Device(
                    mapMessage.getString("id"),
                    mapMessage.getString("name"),
                    mapMessage.getString("address"),
                    mapMessage.getString("macAddress"),
                    mapMessage.getString("status"),
                    mapMessage.getString("type"),
                    mapMessage.getString("version")
            );
            return device;
        }else{
            String status = mapMessage.getString("status-X");
            return status;
        }
    }

}
