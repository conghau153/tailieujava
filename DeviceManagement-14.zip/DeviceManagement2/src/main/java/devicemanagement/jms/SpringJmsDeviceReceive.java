package devicemanagement.jms;

import devicemanagement.model.Device;
import org.springframework.jms.core.support.JmsGatewaySupport;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;


//public class SpringJmsDeviceReceive extends JmsGatewaySupport {
//    public Object receiveMessage() throws JMSException {
//        Object obj= getJmsTemplate().receiveAndConvert();
//        if (obj instanceof Device){
//            Device device = (Device) obj;
//            return device;
//        }else{
//            String status= (String) obj;
//            return status;
//        }
//    }
//}

public class SpringJmsDeviceReceive implements MessageListener{

    public void onMessage(Message message) {
        MapMessage mapMessage = (MapMessage) message;
        try {
            String status= mapMessage.getString("status-X");
            System.out.println(status);

        } catch (JMSException e) {
            e.printStackTrace();
        }
    }
}