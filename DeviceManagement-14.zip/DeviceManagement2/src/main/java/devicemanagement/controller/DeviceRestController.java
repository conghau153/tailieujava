package devicemanagement.controller;

import devicemanagement.app.ConsumerMessageListener;
import devicemanagement.jms.SpringJmsDeviceReceive;
import devicemanagement.jms.SpringJmsDeviceSender;
import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import devicemanagement.model.ViewDevice;

import javax.jms.*;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceDAO deviceDAO;

    @Autowired
    SpringJmsDeviceSender springJmsDeviceSender;

    @Autowired
    SpringJmsDeviceReceive springJmsDeviceReceive;

     /*---------------- GET ALL DEVICE ------------------------ */
    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    @ResponseBody
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");
        List<Device> listDevice = deviceDAO.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();
        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }

    /*---------------- CREATE DEVICE  ------------------------ */
    @RequestMapping(value="/devices", method = RequestMethod.POST)
    @ResponseBody
    public String addDevice(@RequestBody ViewDevice viewDevice){

        Device device = viewDevice.convertToDevice();
        springJmsDeviceSender.sendMessage(device);

        deviceDAO.messageAddDevice();

        String status = "Error create";
        try {
            status = (String) springJmsDeviceReceive.receiveMessage();
        } catch (JMSException e) {
            e.printStackTrace();
        }
        return status;
    }

    /* ---------------- GET DEVICE BY ID ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
    @ResponseBody
    public  Object getDeviceById(@PathVariable String id) {
        Device device = deviceDAO.getDeviceById(id);
        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }

    /*---------------- GET DEVICE BY MAC ADDRESS ------------------------ */
    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
    @ResponseBody
    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
        Device device = deviceDAO.getDeviceByMacAddress(macAddress);

        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }


    /*---------------- DELETE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteDeviceById(@PathVariable String id) throws JMSException {
        Device device = deviceDAO.getDeviceById(id);
        if (device == null) {
            return "Not Found UserDevice";
        }else{
            //boolean ok=deviceDAO.deleteDevice(device);
            springJmsDeviceSender.sendMessage(device);

//            Connection connection = null;
//            ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
//                    "tcp://localhost:61616");
//            connection = connectionFactory.createConnection();
//
//            Session session = connection.createSession(false,
//                    Session.AUTO_ACKNOWLEDGE);
//
//            try {
//                Queue queue = session.createQueue("messageQueue");
//
//                // Consumer
//                MessageConsumer consumer = session.createConsumer(queue);
//                ConsumerMessageListener consumerListener = new ConsumerMessageListener();
//                consumer.setMessageListener(consumerListener);
//                consumerListener.setAsyncReceiveQueueClientExample(this);
//
//                connection.start();
//
//            } finally {
//                if (session != null) {
//                    session.close();
//                }
//                if (connection != null) {
//                    connection.close();
//                }
//            }






            //deviceDAO.messageDeleteDevice();

//            String status = "Error delete";
//            try {
//                 status= (String) springJmsDeviceReceive.receiveMessage();
//
//            } catch (JMSException e) {
//                e.printStackTrace();
//            }
//            return status;
            return null;
        }
    }


    /* ---------------- UPDATE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public String updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {

        Device deviceQuery= deviceDAO.getDeviceById(id);
        if (deviceQuery == null) {
            return "Not Found UserDevice";
        }else{
            //viewDevice.setId(id);
            Device deviceUpdate= viewDevice.convertToDevice();
            boolean ok= deviceDAO.updateDevice(deviceUpdate);
            if (ok)
                return "Updated!";
            else
                return "Error update";
        }
    }
}