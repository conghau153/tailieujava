package devicemanagement.controller;

import devicemanagement.model.Device;
import devicemanagement.service.DeviceDAO;
import org.junit.Before;
import org.junit.Test;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.mockito.runners.MockitoJUnitRunner;
import devicemanagement.model.ViewDevice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

import static org.mockito.Mockito.when;

public class DeviceRestControllerTest {

    @Mock
    private DeviceDAO deviceDAO;

    @InjectMocks
    private DeviceRestController deviceRestController;

    Device device = new Device();
    Device device1 = new Device();
    Device device2 = new Device();
    Device device3 = new Device();
    Device deviceA = new Device();
    Device deviceB = new Device();
    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);

        device.setId("5be15357f9d8487d938669a7");
        device.setName("vxTarget");
        device.setAddress("10.1.2.125");
        device.setMacAddress("eB:e7:32:de:f0:9B");
        device.setStatus("Up");
        device.setType("0S6450-U245");
        device.setVersion("6.7.2.107");


        device1.setId("5be15364f9d8487d938669a10");
        device1.setName("DCD-2");
        device1.setAddress("10.1.3.95");
        device1.setMacAddress("eB:f2:32:f3:a3:9h");
        device1.setStatus("Up");
        device1.setType("0S5686200");
        device1.setVersion("8.1.2.1");


        device2.setName("ABC");
        device2.setAddress("10.1.3.85");
        device2.setType("0S56862-A");
        device2.setVersion("8.1.1.2");

        device3.setName("ABC");
        device3.setAddress("10.1.3.85");
        device3.setType("0S56862-A");

        deviceA.setId("5be15357f9d8487d938669a16");
        deviceA.setName("DGF");
        deviceA.setAddress("10.1.2.98");
        deviceA.setMacAddress("eB:e7:32:de:f0:5H");
        deviceA.setStatus("Warning");
        deviceA.setType("0S6450-2");
        deviceA.setVersion("6.7.2.1");

        deviceB.setId("5be15357f9d8487d938669a17");
        deviceB.setName("DGF-3");
        deviceB.setAddress("10.1.2.99");
        deviceB.setMacAddress("eB:e7:32:de:f0:5H");
        deviceB.setStatus("Warning");
        deviceB.setType("0S6450-3");
        deviceB.setVersion("6.7.2.3");
    }

    @Test
    public void getAllDeviceTest() {
        List<Device> devices = new ArrayList<Device>();
        devices.add(device1);

        List<ViewDevice> viewDevices = new ArrayList<ViewDevice>();
        viewDevices.add(new ViewDevice(device1));

        when(deviceDAO.getListDevice()).thenReturn(devices);
        assertEquals( viewDevices, deviceRestController.getAllDevice());
    }

    @Test
    public void getDeviceByIdTest() {
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a2")).thenReturn(null);
        ViewDevice viewDevice= new ViewDevice(device);

        assertEquals(viewDevice, deviceRestController.getDeviceById("5be15357f9d8487d938669a7"));
        assertEquals("Not Found Device", deviceRestController.getDeviceById("5be15357f9d8487d938669a2"));
    }

    @Test
    public void getDeviceByMacAddressTest() {
        ViewDevice viewDevice= new ViewDevice(device);
        when(deviceDAO.getDeviceByMacAddress("eB:e7:32:de:f0:9B")).thenReturn(device);
        when(deviceDAO.getDeviceByMacAddress("eB:e7:32:de:f0:9A")).thenReturn(null);


        assertEquals(viewDevice, deviceRestController.getDeviceByMacAddress("eB:e7:32:de:f0:9B"));
        assertEquals("Not Found Device", deviceRestController.getDeviceByMacAddress("eB:e7:32:de:f0:9A"));
    }

    @Test
    public void testAddDeviceTest()  {
        ViewDevice viewDevice = new ViewDevice(device);
        when(deviceDAO.addDevice(device)).thenReturn(true);

        ViewDevice viewDevice1 = new ViewDevice(device1);
        when(deviceDAO.addDevice(device1)).thenReturn(false);

        ViewDevice viewDevice2 = new ViewDevice(device2);

        ViewDevice viewDeviceA = new ViewDevice(deviceA);
        when(deviceDAO.getDeviceByMacAddress(deviceA.getMacAddress())).thenReturn(deviceB);

        assertEquals("Created",deviceRestController.addDevice(viewDevice));
        assertEquals("Error create",deviceRestController.addDevice(viewDevice1));
        assertEquals("Name or Address or MAC Address or Status or Type or Version is NULL"
                ,deviceRestController.addDevice(viewDevice2));
        assertEquals("MAC Address is existed",deviceRestController.addDevice(viewDeviceA));
    }

    @Test
    public void testUpdateDevice() {
        ViewDevice viewDevice= new ViewDevice(device);
        ViewDevice viewDevice2= new ViewDevice(device2);
        ViewDevice viewDevice3= new ViewDevice(device2);

        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device2);
        device2.setId("5be15357f9d8487d938669a7");

        when(deviceDAO.updateDevice(device2)).thenReturn(true);

        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a9")).thenReturn(null);



        assertEquals("Updated!",
                deviceRestController.updateDevice("5be15357f9d8487d938669a7",viewDevice2));


        assertEquals("Error update",
                deviceRestController.updateDevice("5be15357f9d8487d938669a9",viewDevice3));

        assertEquals("User can only modify the following attributes: name, address, type, version",
                deviceRestController.updateDevice("5be15357f9d8487d938669a7",viewDevice));


        assertEquals("name and address and type and version are NULL",
                deviceRestController.updateDevice("5be15357f9d8487d938669a9",new ViewDevice()));



    }

    @Test
    public void testDeleteDevice()  {
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a7")).thenReturn(true);
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a9")).thenReturn(false);

        assertEquals("Deleted",deviceRestController.deleteDeviceById("5be15357f9d8487d938669a7"));

        assertEquals("Error delete",deviceRestController.deleteDeviceById("5be15357f9d8487d938669a9"));
    }

    @Test
    public void testDeleteMultiDevice()  {
        List<String> idList1= Arrays.asList("5be15357f9d8487d938669a7"
                                            ,"5be15357f9d8487d938669a8"
                                            ,"5be15357f9d8487d938669a9");
        List<String> idList2= Arrays.asList("5be15357f9d8487d938669a7"
                                            ,"5be15357f9d8487d938669a8"
                                            ,"5be15357f9d8487d938669a11");
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a7")).thenReturn(device);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a8")).thenReturn(device1);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a9")).thenReturn(device2);
        when(deviceDAO.getDeviceById("5be15357f9d8487d938669a11")).thenReturn(null);

        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a7")).thenReturn(true);
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a8")).thenReturn(true);
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a9")).thenReturn(true);
        when(deviceDAO.deleteDevice("5be15357f9d8487d938669a11")).thenReturn(false);

        assertEquals("Deleted multi device",deviceRestController.deleteMultiDevice(idList1));

        assertEquals(" Error delete Multi device",deviceRestController.deleteMultiDevice(idList2));
    }



}
