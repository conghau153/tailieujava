package devicemanagement.service;

import devicemanagement.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements UserDAO {
    @Autowired
    MongoTemplate mongoTemplate;

    public static final String CollectionUser = "user";

    public User getUser(String username) {
        User user= mongoTemplate.findOne(Query.query(Criteria.where("username").is(username)), User.class,"user");
        return user;
    }

}
