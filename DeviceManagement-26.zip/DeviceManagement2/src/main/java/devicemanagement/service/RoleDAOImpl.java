package devicemanagement.service;

import devicemanagement.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RoleDAOImpl implements RoleDAO {
    @Autowired
    MongoTemplate mongoTemplate;

    public static final String CollectionRoleUser = "role";

    public List<Role> getRoleUser(String userId) {
        List<Role> roleUser= mongoTemplate.find(Query.query(Criteria.where("userId").is(userId)), Role.class,CollectionRoleUser);
        return roleUser;
    }

}
