package devicemanagement.service;

import devicemanagement.model.Event;

public interface EventDAO {
    void addEvent(Event event);
}
