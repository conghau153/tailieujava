package devicemanagement.schedule;

import devicemanagement.model.Event;
import devicemanagement.observer.Subject;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

public class ScheduleExecutor {
    @Autowired
    DeviceDAO deviceDAO;

    @Autowired
    Subject subject;

    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1);

    final Runnable beeper = new Runnable() {
        public void run() {
            Event event= new Event();
            event.setMacAddress(deviceDAO.getMacAddress());
            event.setStatus(getRandomStatus());
            subject.setEvent(event);

        }
    };

    final ScheduledFuture<?> beeperHandle =
            scheduler.scheduleAtFixedRate(beeper, 5, 5,MINUTES);


    String getRandomStatus(){
        Random random = new Random();
        int idx= random.nextInt(3);

        if (idx==0)
            return  "Warning";
        else
        if (idx==1)
            return  "Up";
        else
            return  "Down";
    }
}
