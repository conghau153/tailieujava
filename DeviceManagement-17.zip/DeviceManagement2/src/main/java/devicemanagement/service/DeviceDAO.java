package devicemanagement.service;
import devicemanagement.model.Device;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface DeviceDAO {

    List<Device> getListDevice();

    boolean addDevice(Device device);

    boolean updateDevice(Device device);

    boolean deleteDevice(Device device);

    Device getDeviceById(String id);

    Device getDeviceByMacAddress(String macAddress);

    boolean isExists(Device device);
}