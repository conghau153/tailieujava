package devicemanagement.jms.queue;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;


public class JmsMessage {

    //private static CountDownLatch latch ;
    public void receiveMessages(String queueName, int countDownLatch ) throws JMSException, InterruptedException {
        //set up count Down Latch
        //latch= new CountDownLatch(countDownLatch);

        Connection connection = null;
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(
                "tcp://localhost:61616");
        connection = connectionFactory.createConnection();

        Session session = connection.createSession(false,
                Session.AUTO_ACKNOWLEDGE);

        try {
            //set up queue
            Queue queue = session.createQueue(queueName);

            // Consumer
            MessageConsumer consumer = session.createConsumer(queue);

            JmsMessageListener consumerListener = new JmsMessageListener();

            consumer.setMessageListener(consumerListener);
            //consumerListener.setAsyncReceiveQueueClientExample(this);

            connection.start();
           // latch.await();
            Thread.sleep(10000);
        } finally {
            if (session != null) {
                session.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    public static void latchCountDown() {
        //latch.countDown();
    }
}
