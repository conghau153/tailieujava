package devicemanagement.observer;

import devicemanagement.model.DeviceEvent;

import java.util.ArrayList;
import java.util.List;


public class Event {

    List<Observer> observers = new ArrayList<Observer>();
    private DeviceEvent deviceEvent;

    public Event(){}

    public DeviceEvent getDeviceEvent() {
        return deviceEvent;
    }

    public void setDeviceEvent(DeviceEvent deviceEvent) {
        this.deviceEvent = deviceEvent;
        notifyAllObservers();
    }
    public void attach(Observer observer){
        observers.add(observer);
    }

    public void notifyAllObservers(){

            for (Observer observer: observers){
                observer.update();
            }

    }
}
