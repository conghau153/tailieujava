package devicemanagement.observer;


public abstract class Observer {
    protected Event event;
    public abstract  void update();

}
