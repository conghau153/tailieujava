package devicemanagement.observer;

import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

public class ListenerEventObserver extends  Observer{
    @Autowired
    DeviceDAO deviceDAO;

    public ListenerEventObserver(Event event) {
        this.event = event;
        this.event.attach(this);
    }

    public void update() {
        //save to mongodb
        deviceDAO.updateEvent(event.getDeviceEvent());
        System.out.println("update: " + event.getDeviceEvent().toString());
    }
}
