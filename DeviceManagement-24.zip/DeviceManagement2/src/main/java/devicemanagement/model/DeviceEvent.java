package devicemanagement.model;


public class DeviceEvent {
    String macAddress, status;

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "{" + this.macAddress + " , " + this.status + "}";
    }

}
