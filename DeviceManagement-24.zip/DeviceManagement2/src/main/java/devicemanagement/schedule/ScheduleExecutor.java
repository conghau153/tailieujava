package devicemanagement.schedule;

import devicemanagement.model.DeviceEvent;
import devicemanagement.observer.Event;
import devicemanagement.service.DeviceDAO;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.MINUTES;
import static java.util.concurrent.TimeUnit.SECONDS;

public class ScheduleExecutor {
    @Autowired
    DeviceDAO deviceDAO;

    @Autowired
    Event event;

    private final ScheduledExecutorService scheduler =
            Executors.newScheduledThreadPool(1);

    final Runnable beeper = new Runnable() {
        public void run() {
            DeviceEvent deviceEvent= new DeviceEvent();
            deviceEvent.setMacAddress(deviceDAO.getMacAddress());
            deviceEvent.setStatus(getRandomStatus());
            event.setDeviceEvent(deviceEvent);

        }
    };

    final ScheduledFuture<?> beeperHandle =
            scheduler.scheduleAtFixedRate(beeper, 5, 5,MINUTES);


    String getRandomStatus(){
        Random random = new Random();
        int idx= random.nextInt(3);

        if (idx==0)
            return  "Warning";
        else
        if (idx==1)
            return  "Up";
        else
            return  "Down";
    }
}
