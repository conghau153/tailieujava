package springmvc.devicemanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import springmvc.devicemanagement.model.Role;

@Repository
public class RoleServiceImpl implements RoleService {
    @Autowired
    MongoTemplate mongoTemplate;

    public static final String CollectionRoleUser = "role";

    public Role getRoleUser(String userId) {
        Role roleUser= mongoTemplate.findOne(Query.query(Criteria.where("userId").is(userId)), Role.class,CollectionRoleUser);
        return roleUser;
    }

    public boolean isExitsRoleUser(Role role) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(role.getId()));
        query.addCriteria(Criteria.where("userId").is(role.getUserId()));
        query.addCriteria(Criteria.where("role").is(role.getRole()));

        Role roleQuery= mongoTemplate.findOne(query,Role.class,CollectionRoleUser);
        if (roleQuery!=null)
            return true;
        else
            return false;
    }
}
