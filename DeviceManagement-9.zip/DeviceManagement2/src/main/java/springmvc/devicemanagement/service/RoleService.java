package springmvc.devicemanagement.service;

import springmvc.devicemanagement.model.Role;

public interface RoleService {
    Role getRoleUser(String userId);
    boolean isExitsRoleUser(Role role);
}
