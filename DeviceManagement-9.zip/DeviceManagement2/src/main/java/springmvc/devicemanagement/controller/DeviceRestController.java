package springmvc.devicemanagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.service.DeviceService;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;


import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceService deviceDao;

    

     /*---------------- GET ALL DEVICE ------------------------ */
    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    @ResponseBody
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");
        List<Device> listDevice = deviceDao.getListDevice();

        List<ViewDevice> listAllDevice= new ArrayList<ViewDevice>();
        for (Device device: listDevice){
            ViewDevice viewDevice= new ViewDevice(device);
            listAllDevice.add(viewDevice);
        }
        return listAllDevice;
    }

}
