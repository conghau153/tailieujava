package springmvc.devicemanagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;
import springmvc.devicemanagement.service.DeviceDAO;

import java.util.Collection;
import java.util.List;


@Controller
public class DeviceController {
    @Autowired
    private DeviceDAO deviceDao;

    String error="";

    //@PreAuthorize("hasAnyRole('ROLE_MEMBER','ROLE_ADMIN')")
    @RequestMapping("/listDevice")
    public ModelAndView listDevice(){
        ModelAndView model = null;
        if ("[ROLE_ADMIN]".equals(getHasRole()) || "[ROLE_MEMBER]".equals(getHasRole())){
            //write the code to get all device from DAO
            List<ViewDevice> listViewDevice=deviceDao.getListDevice();

            model = new ModelAndView("listDevice");
            model.addObject("list",listViewDevice);
            model.addObject("user",getPrincipal());
            //return new ModelAndView("listDevice","list",listViewDevice);
        }
        else{
            model = new ModelAndView("redirect:/login");
        }
        return model;
    }

    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping("/formDevice")
    public ModelAndView showFormDevice(){
        ModelAndView model;
        if ("[ROLE_ADMIN]".equals(getHasRole())){
            //command is a reserved request attribute name, now use <form> tag to show object data
            model = new ModelAndView("formDevice");
            model.addObject("command",new ViewDevice());

            //set a message error in form device
            model.addObject("msg",error);
            if (!"".equals(error)) error="";
        }
        else{
            model = new ModelAndView("redirect:/login");
        }


        return model;
        //return new ModelAndView("deviceform","command",new Device());
    }

    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/save",method = RequestMethod.POST)
    public ModelAndView saveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){
        if ("[ROLE_ADMIN]".equals(getHasRole())){
            //check MAC Address in mongoDB
            ViewDevice devi= deviceDao.getDeviceByMacAddress(viewDevice.getMacAddress());

            //check form add new device
            Boolean check = "".equals(viewDevice.getAddress())
                    || "".equals(viewDevice.getMacAddress())
                    || "".equals(viewDevice.getName())
                    || "".equals(viewDevice.getType())
                    || "".equals(viewDevice.getVersion())
                    || (viewDevice.getName().length()>128)
                    || (viewDevice.getType().length()>64)
                    || (viewDevice.getVersion().length()>64);

            if (devi!=null || check ){
                error= "Can not add new device ";
                //return new ModelAndView("redirect:/deviceform");
                return showFormDevice();
            }else{
                deviceDao.addDevice(viewDevice);
                return new ModelAndView("redirect:/listDevice");//will redirect to listDevice request mapping
            }
        }else {
            return new ModelAndView("redirect:/login");
        }
    }

    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/editDevice/{id}")
    public ModelAndView editDevice(@PathVariable String id){
        if ("[ROLE-ADMIN".equals(getHasRole())){
            //get a device by id
            Device device=deviceDao.getDeviceById(id);
            ViewDevice viewDevice;
            if (device!=null){
                viewDevice = new ViewDevice(device);
            }else{
                viewDevice = new ViewDevice();
            }

            //return device to editFormDevice
            return new ModelAndView("editFormDevice","command",viewDevice);
        }
        else {
            return new ModelAndView("redirect:/login");
        }
    }


    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/editSave",method = RequestMethod.POST)
    public ModelAndView editSaveDevice(@ModelAttribute("viewDevice") ViewDevice viewDevice){
        if ("[ROLE_ADMIN]".equals(getHasRole())){
            if (viewDevice!= null){
                deviceDao.updateDevice(viewDevice);
            }
            return new ModelAndView("redirect:/listDevice");
        }
        else{
            return new ModelAndView("redirect:/login");
        }

    }

    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/deleteDevice/{id}",method = RequestMethod.GET)
    public ModelAndView deleteDevice(@PathVariable("id") String id){
        if ("[ROLE_ADMIN]".equals(getHasRole())){
            if (id!=null ){
                ViewDevice viewDevice= new ViewDevice();
                viewDevice.setId(id);
                deviceDao.deleteDevice(viewDevice);
            }

            return new ModelAndView("redirect:/listDevice");
        }else{
            return  new ModelAndView("redirect:/login");
        }

    }

    /*@RequestMapping(value = "/", method = RequestMethod.GET)
    public String indexPage(ModelMap model) {

        model.addAttribute("message", "Hello Guest, this is the Home Page...");
        return "index";
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/admin", method = RequestMethod.GET)
    public String adminPage(ModelMap model) {


        model.addAttribute("user", getPrincipal());
        model.addAttribute("message", "Admin Page...");
        return "admin/admin";
    }

    @PreAuthorize("hasAnyRole('ROLE_MEMBER','ROLE_ADMIN')")
    @RequestMapping(value = "/member", method = RequestMethod.GET)
    public String memberPage(ModelMap model) {
        System.out.println(getHasRole());
        model.addAttribute("user", getPrincipal());
        model.addAttribute("message", "Member Page...");
        return "member/member";
    }*/

    private String getPrincipal(){
        String userName = null;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof UserDetails) {
            userName = ((UserDetails)principal).getUsername();
        } else {
            //userName = principal.toString();
            userName="";
        }
        return userName;
    }

    private  String getHasRole(){
        String hasRole=null;

        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails){
            hasRole= ((UserDetails)principal).getAuthorities().toString();
        }else{
            hasRole="";
        }
        System.out.println(hasRole);
        return hasRole;
        //System.out.println(hasRole);
    }
}