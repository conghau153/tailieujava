package springmvc.devicemanagement.service;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;

import java.util.List;

public interface DeviceDAO {

    List<ViewDevice> getListDevice();
    int addDevice(ViewDevice viewDevice);

    ViewDevice updateDevice(ViewDevice viewDevice);
    int deleteDevice(ViewDevice viewDevice);

    Device getDeviceById(String id);
    ViewDevice getDeviceByMacAddress(String macAddress);
}