package springmvc.devicemanagement.service;


import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;


import org.mockito.stubbing.OngoingStubbing;
import org.springframework.test.context.ContextConfiguration;
import springmvc.devicemanagement.model.Device;


import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@ContextConfiguration("file:my-context-file.xml")
@RunWith(MockitoJUnitRunner.class)

public class TestDeviceDAO {
    //use mock test DeviceDAO
    @Mock
    static DeviceDAO deviceDAO;

    static List<Device> list_device= new ArrayList<Device>();
    static Device device1, device2, device3, device4;

    @BeforeClass
    public static void init(){
        device1= new Device();
        device1.setId("5be15357f9d8487d938669a7");
        device1.setName("vxTarget");
        device1.setAddress("10.1.2.125");
        device1.setMacAddress("eB:e7:32:de:f0:9B");
        device1.setStatus("Up");
        device1.setType("0S6450-U245");
        device1.setVersion("6.7.2.107");

        device2= new Device();
        device2.setId("5be15364f9d8487d938669a8");
        device2.setName("ABC");
        device2.setAddress("10.1.3.5");
        device2.setMacAddress("eB:f2:32:gd:f0:9B");
        device2.setStatus("Up");
        device2.setType("0S6450-U245");
        device2.setVersion("6.7.2.5");

        device3= new Device();
        device3.setId("5be15364f9d8487d9386578a8");
        device3.setName("BDE");
        device3.setAddress("10.1.2.16");
        device3.setMacAddress("eB:f2:32:gd:h1:g0");
        device3.setStatus("Warning");
        device3.setType("0S645056-23");
        device3.setVersion("7.4.2.17");

        device4= new Device();
        device4.setId("5be15364f9d8487d938669a10");
        device4.setName("DCD-2");
        device4.setAddress("10.1.3.95");
        device4.setMacAddress("eB:f2:32:f3:a3:9h");
        device4.setStatus("Up");
        device4.setType("0S5686200");
        device4.setVersion("8.1.2.1");

        list_device.add(device1);
        list_device.add(device2);
        list_device.add(device3);
    }

    @Test
    public void getDeviceByIdTest(){
        /*
        //when(deviceDAO.getListDevice()).thenReturn(list_device);
        //set mock getDeviceByMacAddress
        when(deviceDAO.getDeviceById("5be15364f9d8487d938669a8")).thenReturn(device2);

        //check result
        assertEquals(device2,deviceDAO.getDeviceById("5be15364f9d8487d938669a8"));
        */
    }

    @Test
    public void getDiviceByMacAddressTest(){
        /*
        //when(deviceDAO.getListDevice()).thenReturn(list_device);
        //set mock getDeviceByMacAddress
        when(deviceDAO.getDeviceByMacAddress("eB:f2:32:gd:f0:9B")).thenReturn(device2);

        //check result
        assertEquals(device2,deviceDAO.getDeviceByMacAddress("eB:f2:32:gd:f0:9B"));
        */
    }
    @Test
    public void getListDeviceTest(){
        /*
        //set mock getListDevice return list_device
        when(deviceDAO.getListDevice()).thenReturn(list_device);

        //check size list_device
        assertEquals(3,deviceDAO.getListDevice().size());
        */
    }

    @Test
    public void addDeviceTest(){
        /*
        //set mock addDevice add a device return size new list_device
        when(deviceDAO.addDevice(device4)).thenReturn(4);

        //check
        assertEquals(4,deviceDAO.addDevice(device4));
        */
    }

    @Test
    public void updateDeviceTest(){
        /*
        Device deviceUpdate = new Device();
        deviceUpdate.setId("5be15364f9d8487d9386578a8");
        deviceUpdate.setName("BDE-X");
        deviceUpdate.setAddress("10.1.2.16");
        deviceUpdate.setMacAddress("eB:f2:32:gd:h1:g0");
        deviceUpdate.setStatus("Warning");
        deviceUpdate.setType("0S645056-23");
        deviceUpdate.setVersion("7.4.2.18");

        //set mock updateDevice
        when(deviceDAO.updateDevice(device3)).thenReturn(deviceUpdate);

        //check
        assertEquals(deviceUpdate,deviceDAO.updateDevice(device3));
        */
    }
    @Test
    public void deleteDeviceTest(){
       /*
        //set a mock deleteDevice by macAddress return size list_device
        when(deviceDAO.deleteDevice(device2)).thenReturn(2);
        //check result
        assertEquals(2,deviceDAO.deleteDevice(device2));
        */
    }

}
