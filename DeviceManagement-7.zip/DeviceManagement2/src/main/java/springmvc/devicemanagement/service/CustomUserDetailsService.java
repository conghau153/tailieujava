package springmvc.devicemanagement.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import springmvc.devicemanagement.model.Role;
import springmvc.devicemanagement.model.User;
import springmvc.devicemanagement.model.ViewUser;


import java.util.ArrayList;
import java.util.List;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    DeviceDAO deviceDao;

    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {
        //System.out.println(username);
        User user = deviceDao.getUser(username) ;
        System.out.println(user);
        System.out.println("UserDevice : "+user);
        if(user==null){
            System.out.println("UserDevice not found");
            throw new UsernameNotFoundException("Username not found");
        }
        ViewUser viewUser = new ViewUser(user.getId(),user.getUsername(),user.getPassword());

//        return new org.springframework.security.core.userdetails.UserDevice(user.getUsername(), user.getPassword(),
//               true, true, true, true, getGrantedAuthorities(user));

//        return new org.springframework.security.core.userdetails.UserDevice(user.getUsername(), user.getPassword(),
//                user.getState().equals("Active"), true, true, true, getGrantedAuthorities(user));

//        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
//        User user1 = new User("admin", "admin", authorities);
        return new org.springframework.security.core.userdetails.User("admin", "admin",
                true, true, true, true,
                getGrantedAuthorities(viewUser));
    }


    private List<GrantedAuthority> getGrantedAuthorities(ViewUser user){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

//        for(UserProfile userProfile : user.getUserProfiles()){
//            System.out.println("UserProfile : "+userProfile);
//            authorities.add(new SimpleGrantedAuthority("ROLE_"+userProfile.getType()));
//        }
//        System.out.print("authorities :"+authorities);



        Role roleUser = deviceDao.getRoleUser(user.getId());
        authorities.add(new SimpleGrantedAuthority(roleUser.getRole()));

        /*if("admin".equalsIgnoreCase(user.getUsername())) {
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        }else{
            authorities.add(new SimpleGrantedAuthority("ROLE_MEMBER"));
        }*/

        //authorities.add(new SimpleGrantedAuthority(roleUser.getRole()));
        System.out.print("authorities :"+authorities);
        return authorities;
    }
}
