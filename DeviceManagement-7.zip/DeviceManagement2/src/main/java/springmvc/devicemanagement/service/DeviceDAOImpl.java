package springmvc.devicemanagement.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import springmvc.devicemanagement.model.*;


@Repository
public class DeviceDAOImpl implements DeviceDAO {
    @Autowired
    private MongoTemplate mongoTemplate;

    public static final String COLLECTIONNAME = "device";
    public static final String CollectionUser = "user";
    public static final String CollectionRoleUser = "role";

    /**
     * implement a getListDevice method return list device
     * findAll device from mongo
     * covert device to ViewDevice
     * @return a list ViewDevice
     */
    public List<ViewDevice> getListDevice() {
        List<Device> listDevice= mongoTemplate.findAll(Device.class, COLLECTIONNAME);
        List<ViewDevice> listViewDevice = new ArrayList<ViewDevice>();
        //System.out.println(mongoTemplate.);
        if (listDevice.size()>0){
            for (Device d: listDevice){
                ViewDevice viewDevice = new ViewDevice(d);
                listViewDevice.add(viewDevice);
            }
        }
        return listViewDevice;
    }

    /**
     * implement addDevice method
     * covert a viewDevice to a device
     * insert device into mongo
     * @param viewDevice
     * @return size list device after insert device
     */
    public int addDevice(ViewDevice viewDevice) {
        if (viewDevice !=null){
            Device device = viewDevice.convertToDevice();
            //device.setId(UUID.randomUUID().toString());
            mongoTemplate.insert(device, COLLECTIONNAME);
        }

        return mongoTemplate.findAll(Device.class, COLLECTIONNAME).size();
    }

    /**
     * implement updateDevice
     * @param viewDevice
     * @return a ViewDevice
     */
    public ViewDevice updateDevice(ViewDevice viewDevice) {
        Device device= getDeviceById(viewDevice.getId());
        if (device!=null){
            device.setName(viewDevice.getName());
            device.setAddress(viewDevice.getAddress());
            device.setType(viewDevice.getType());
            device.setVersion(viewDevice.getVersion());

            mongoTemplate.save(device,COLLECTIONNAME);
        }
        else
            addDevice(viewDevice);

        return viewDevice;
    }

    /**
     *
     * @param viewDevice
     * @return
     */
    public int deleteDevice(ViewDevice viewDevice) {
        //System.out.println(viewDevice.getName());
        Device device= getDeviceById(viewDevice.getId());
        if (device!=null){
            mongoTemplate.remove(device, COLLECTIONNAME);
        }
        return mongoTemplate.findAll(Device.class, COLLECTIONNAME).size();
    }

    /**
     * implement a getDeviceById method
     * @param id
     * @return a view device
     */
    public Device getDeviceById(String id) {
        Device device=  mongoTemplate.findOne(Query.query(Criteria.where("_id").is(id)), Device.class,COLLECTIONNAME);

        return device;
    }

    /**
     * implement a getDeviceByMacAddress
     * @param macAddress
     * @return a device by macAddress
     */
    public ViewDevice getDeviceByMacAddress(String macAddress) {
        Device device=  mongoTemplate.findOne(Query.query(Criteria.where("macAddress").is(macAddress)), Device.class,COLLECTIONNAME);
        if (device!=null){
            ViewDevice viewDevice= new ViewDevice(device);
            return  viewDevice;
        }
        else
            return null;
    }

    public User getUser(String username) {
        List<User> listUser = mongoTemplate.findAll(User.class,"user");
        List<Device> listDevice = mongoTemplate.findAll(Device.class,"device");
        List<Role> listRole = mongoTemplate.findAll(Role.class,"role");
        User user= mongoTemplate.findOne(Query.query(Criteria.where("username").is(username)), User.class,"user");
        return user;
    }

    public Role getRoleUser(String userId) {
        Role roleUser= mongoTemplate.findOne(Query.query(Criteria.where("userId").is(userId)), Role.class,CollectionRoleUser);
        return roleUser;
    }
}