package springmvc.devicemanagement.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.Device;
import springmvc.devicemanagement.model.ViewDevice;
import springmvc.devicemanagement.service.DeviceDAO;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping(value = "/api")
public class DeviceRestController {
    private static final Logger logger =
            LoggerFactory.getLogger(DeviceRestController.class);

    @Autowired
    DeviceDAO deviceDao;

    String error="";

   /* @RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
    public ModelAndView accesssDenied(Principal user) {
        ModelAndView model = new ModelAndView();
        if (user != null) {
            model.addObject("msg", "Hi " + user.getName()
                    + ", you do not have permission to access this page!");
        } else {
            model.addObject("msg",
                    "You do not have permission to access this page!");
        }
        model.setViewName("403");
        return model;
    }

    @RequestMapping("/listDevice")
    public ModelAndView getAll(Principal user){

        ModelAndView model = null;
        //write the code to get all device from DAO
        List<ViewDevice> listViewDevice=deviceDao.getListDevice();

        model = new ModelAndView("listDevice");
        model.addObject("list",listViewDevice);
        model.addObject("user","user: "+user.getName());

        return model;
    }


    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(){
        return "login";
    }

    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }*/




     /*---------------- GET ALL DEVICE ------------------------ */
    @RequestMapping(value = "/devices", method = RequestMethod.GET)
    @ResponseBody
    public List<ViewDevice> getAllDevice() {
        logger.debug("================================TEST========================");
        List<ViewDevice> listDevice = deviceDao.getListDevice();
        return listDevice;
    }

    /* ---------------- GET DEVICE BY ID ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
    @ResponseBody
    public  Object getDeviceById(@PathVariable String id) {
        ViewDevice viewDevice = new ViewDevice(deviceDao.getDeviceById(id));
        if (viewDevice != null) {
            return viewDevice;
        }
        return "Not Found UserDevice";
    }

     /*---------------- GET DEVICE BY MAC ADDRESS ------------------------ */
    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
    @ResponseBody
    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
        ViewDevice viewDevice = deviceDao.getDeviceByMacAddress(macAddress);
        if (viewDevice != null) {
            return viewDevice;
        }
        return "Not Found UserDevice";
    }

     /*---------------- CREATE DEVICE  ------------------------ */
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value="/devices", method = RequestMethod.POST)
    @ResponseBody
    public String addDevice(@RequestBody ViewDevice viewDevice){
        Device device = deviceDao.getDeviceById(viewDevice.getId());
        //System.out.println(viewDevice.getName());

        if (device!=null) {
            return "Device Already Exist!";
        }
        deviceDao.addDevice(viewDevice);
        return "created";
    }


     /*---------------- DELETE DEVICE ------------------------ */
    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteDeviceById(@PathVariable String id) {
        Device device = deviceDao.getDeviceById(id);
        if (device == null) {
            return "Not Found UserDevice";
        }

        deviceDao.deleteDevice(new ViewDevice(device));

        return "Deleted!";
    }

    /* ---------------- UPDATE DEVICE ------------------------ */
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    public ResponseEntity<String> updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {

        Device device= deviceDao.getDeviceById(id);
        if (device == null) {
            return new ResponseEntity<String>("Not Found UserDevice", HttpStatus.NO_CONTENT);
        }

        deviceDao.updateDevice(viewDevice);
        return new ResponseEntity<String>("Updated!", HttpStatus.OK);
    }
}
