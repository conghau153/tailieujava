package springmvc.devicemanagement.controller;


import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import springmvc.devicemanagement.model.ViewDevice;
import springmvc.devicemanagement.service.DeviceDAO;
import sun.misc.BASE64Encoder;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import java.util.ArrayList;
import java.util.List;

@Controller
public class DeviceController {
    @Autowired
    DeviceDAO deviceDao;


    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(){
        return "login";
    }

    @RequestMapping(value="/logout", method = RequestMethod.GET)
    public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null){
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        return "redirect:/login?logout";
    }

    @RequestMapping(value = "/listDevice")
    public ModelAndView getAllDevice(){
        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();
        try {
            Client client = Client.create();

            WebResource webResource = client
                    .resource("http://127.0.0.1:8090/api/devices");

            ClientResponse response = webResource.accept("application/json;charset=UTF-8")
                    .get(ClientResponse.class);

            if (response.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatus());
            }
            JSONArray result =  response.getEntity(JSONArray.class);
            //System.out.println("Output from Server .... \n");
            for (int i=0; i<result.length();i++){
                JSONObject json = (JSONObject) result.get(i);
                ViewDevice viewDevice = convertToViewDevice(json);
                listViewDevice.add(viewDevice);
                //System.out.println(view);
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }

        modelAndView.addObject("list",listViewDevice);
        return modelAndView;
    }

    @RequestMapping(value = "/device/{id}", method = RequestMethod.GET)
    public ModelAndView getDeviceById(@PathVariable String id){
        ModelAndView modelAndView= new ModelAndView("listDevice");
        List<ViewDevice> listViewDevice=new ArrayList<ViewDevice>();

        try {
            String url = "http://127.0.0.1:8090/api/devices/" + id;
            String username = "";
            String password = "";
            String authString = username + ":" + password;
            String authStringEnc = new BASE64Encoder().encode(authString.getBytes());

            Client client = Client.create();

            WebResource webResource = client.resource(url);
            ClientResponse resp = webResource.accept("application/json;charset=UTF-8")
                    .header("Authorization", "Basic " + authStringEnc)
                    .get(ClientResponse.class);


            if (resp.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + resp.getStatus());
            }
            JSONObject obj = resp.getEntity(JSONObject.class);
            ViewDevice viewDevice= convertToViewDevice(obj);
            listViewDevice.add(viewDevice);

            //System.out.println("response: "+obj);
            //listViewDevice.add(output);

        }
        catch (Exception e){
            e.printStackTrace();
        }

        modelAndView.addObject("list",listViewDevice);
        return modelAndView;
    }
    ViewDevice convertToViewDevice(JSONObject jsonObject){
        ViewDevice viewDevice=null;
        try{
            String id = jsonObject.getString("id");
            String name = jsonObject.getString("name");
            String address = jsonObject.getString("address");
            String macAddress = jsonObject.getString("macAddress");
            String status = jsonObject.getString("status");
            String type = jsonObject.getString("type");
            String version = jsonObject.getString("version");
            viewDevice= new ViewDevice(id,name,address,macAddress,status,type,version);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return viewDevice;
    }
}
