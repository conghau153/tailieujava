package springmvc.devicemanagement.service;

import springmvc.devicemanagement.model.User;

public interface UserService {
    User getUser(String username);
    boolean isExitsUser(User user);
}
