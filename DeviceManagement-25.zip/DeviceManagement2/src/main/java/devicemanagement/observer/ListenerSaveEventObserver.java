package devicemanagement.observer;

import devicemanagement.service.EventDAO;
import org.springframework.beans.factory.annotation.Autowired;

public class ListenerSaveEventObserver extends Observer {
    @Autowired
    EventDAO eventDAO;

    public ListenerSaveEventObserver(Subject subject){
        this.subject = subject;
        this.subject.attach(this);
    }

    public void update() {
        eventDAO.addEvent(subject.getEvent());
        System.out.println("save Mongodb collection = event : " + subject.getEvent().toString());
    }
}
