package devicemanagement.observer;

import devicemanagement.model.Event;

import java.util.ArrayList;
import java.util.List;


public class Subject {

    List<Observer> observers = new ArrayList<Observer>();
    private Event event;

    public Subject(){}

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
        notifyAllObservers();
    }
    public void attach(Observer observer){
        observers.add(observer);
    }

    public void notifyAllObservers(){

            for (Observer observer: observers){
                observer.update();
            }

    }
}
