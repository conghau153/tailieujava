package devicemanagement.custom;


import devicemanagement.model.Role;
import devicemanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import devicemanagement.model.User;
import devicemanagement.model.ViewUser;
import devicemanagement.service.RoleService;


import java.util.ArrayList;
import java.util.List;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    UserService userService;

    @Autowired
    RoleService roleService;

    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        User user = userService.getUser(username) ;
        System.out.println(user);
        System.out.println("UserDevice : "+user);
        if(user==null){
            System.out.println("UserDevice not found");
            throw new UsernameNotFoundException("Username not found");
        }
        ViewUser viewUser = new ViewUser(user.getId(),user.getUsername(),user.getPassword());

        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
                true, true, true, true,
                getGrantedAuthorities(viewUser));
    }


    private List<GrantedAuthority> getGrantedAuthorities(ViewUser user){
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        List<Role> listRoleUser = roleService.getRoleUser(user.getId());
        for (Role role : listRoleUser){
            authorities.add(new SimpleGrantedAuthority(role.getRole()));
        }
        //System.out.print("authorities :"+authorities);
        return authorities;
    }
}
