package devicemanagement.controller;


import devicemanagement.model.Device;
import devicemanagement.model.ViewDevice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import devicemanagement.service.DeviceService;


@Controller
@RequestMapping(value = "/api/mngt")
public class MngtDeviceController {

    private static final Logger logger =
            LoggerFactory.getLogger(MngtDeviceController.class);

    @Autowired
    DeviceService deviceDao;

    /*---------------- CREATE DEVICE  ------------------------ */
    @RequestMapping(value="/devices", method = RequestMethod.POST)
    @ResponseBody
    public String addDevice(@RequestBody ViewDevice viewDevice){
        Device device = deviceDao.getDeviceById(viewDevice.getId());

        if (device!=null) {
            return "Device Already Exist!";
        }else{
            Device deviceMacAddress = deviceDao.getDeviceByMacAddress(viewDevice.getMacAddress());
            if (deviceMacAddress!=null){
                return  "exists macAddress";
            }else{

                Device deviceAdd = viewDevice.convertToDevice();
                boolean ok=deviceDao.addDevice(deviceAdd);
                if (ok)
                    return "created";
                else
                    return "Error create";
            }
        }
    }

    /* ---------------- GET DEVICE BY ID ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.GET)
    @ResponseBody
    public  Object getDeviceById(@PathVariable String id) {
        Device device = deviceDao.getDeviceById(id);
        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }

    /*---------------- GET DEVICE BY MAC ADDRESS ------------------------ */
    @RequestMapping(value = "/devices/macAddress/{macAddress}", method = RequestMethod.GET)
    @ResponseBody
    public Object getDeviceByMacAddress(@PathVariable String macAddress) {
        Device device = deviceDao.getDeviceByMacAddress(macAddress);

        if (device != null) {
            ViewDevice viewDevice = new ViewDevice(device);
            return viewDevice;
        }
        return "Not Found Device";
    }


    /*---------------- DELETE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteDeviceById(@PathVariable String id) {
        Device device = deviceDao.getDeviceById(id);
        if (device == null) {
            return "Not Found UserDevice";
        }else{
            boolean ok=deviceDao.deleteDevice(device);
            if (ok)
                return "Deleted!";
            else
                return "Error delete";
        }
    }

    /* ---------------- UPDATE DEVICE ------------------------ */
    @RequestMapping(value = "/devices/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public String updateDevice(@PathVariable String id, @RequestBody ViewDevice viewDevice) {

        Device deviceQuery= deviceDao.getDeviceById(id);
        if (deviceQuery == null) {
            return "Not Found UserDevice";
        }else{
            viewDevice.setId(id);
            Device deviceUpdate= viewDevice.convertToDevice();
            boolean ok= deviceDao.updateDevice(deviceUpdate);
            if (ok)
                return "Updated!";
            else
                return "Error update";
        }
    }

}
