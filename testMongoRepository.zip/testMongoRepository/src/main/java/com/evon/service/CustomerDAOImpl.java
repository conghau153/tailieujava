package com.evon.service;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import com.evon.model.Customer;
@Repository
public class CustomerDAOImpl implements CustomerDAO{
    @Autowired
    private MongoTemplate mongoTemplate;
    public static final String COLLECTIONNAME = "customer";
    public void addCustomer(Customer customer) {
        if (!mongoTemplate.collectionExists(Customer.class)) {
            mongoTemplate.createCollection(Customer.class);
        }
        customer.setId(UUID.randomUUID().toString());
        mongoTemplate.insert(customer, COLLECTIONNAME);
    }
    public List<Customer> listCustomer() {
        return mongoTemplate.findAll(Customer.class, COLLECTIONNAME);
    }
    public void deleteCustomer(Customer customer) {
        mongoTemplate.remove(customer, COLLECTIONNAME);
    }
    public void updateCustomer(Customer customer) {
        mongoTemplate.insert(customer, COLLECTIONNAME);
    }
}