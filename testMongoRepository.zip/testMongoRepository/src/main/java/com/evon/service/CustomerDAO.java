package com.evon.service;
import java.util.List;
import com.evon.model.Customer;
public interface CustomerDAO {
    public void addCustomer(Customer customer);
    public List<Customer> listCustomer();
    public void deleteCustomer(Customer customer);
    public void updateCustomer(Customer customer);
}